# Multi-Role Order Manager

A Flask + SQLite web application supporting three roles: Customer, Manager, Admin.

## Quick Start

```bash
cd order_manager

# 1. Create virtual environment
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set a strong secret key (required in production)
export SECRET_KEY=$(python -c "import secrets; print(secrets.token_hex(32))")

# 4. Run
python app.py
```

Open http://localhost:5000

The database is created automatically on first run at `db/orders.db`.

## Default Credentials

| Role     | Username | Password    |
|----------|----------|-------------|
| Admin    | admin    | Admin1234!  |

> **Change the admin password immediately after first login** (or delete and recreate via Admin → Users).

## Creating Other Users

- **Customers** can self-register at `/register`
- **Managers** must be created by an Admin (Admin Dashboard → Create User)

## Role Capabilities

| Action                  | Customer | Manager | Admin |
|-------------------------|----------|---------|-------|
| Register / login        | ✅       | —       | —     |
| Place orders            | ✅       | —       | —     |
| View own orders         | ✅       | —       | —     |
| View all orders         | —        | ✅      | ✅    |
| Update order status     | —        | ✅      | —     |
| Delete any order        | —        | —       | ✅    |
| Manage users            | —        | —       | ✅    |
| Create manager accounts | —        | —       | ✅    |

## File Structure

```
order_manager/
├── app.py                    Entry point — all routes and logic
├── requirements.txt
├── .env.example
├── prd.md                    Product requirements
├── architecture.json         Architecture design
├── threat_model.md           Threat model (CWE-89, CWE-862, CWE-352, CWE-287, CWE-306)
├── db/
│   ├── schema.sql            Table definitions
│   └── orders.db             Created automatically on first run
├── templates/
│   ├── base.html
│   ├── login.html
│   ├── register.html
│   ├── customer_dashboard.html
│   ├── manager_dashboard.html
│   ├── admin_dashboard.html
│   └── error.html
└── static/
    └── style.css
```

## Security Notes

| Control | Implementation |
|---|---|
| Password hashing | `werkzeug.security` bcrypt |
| SQL injection | Parameterised queries everywhere |
| Role enforcement | `@require_role` decorator re-fetches from DB |
| CSRF protection | Flask-WTF tokens on all forms |
| Privilege escalation | Role hardcoded on register; never from POST |
| BOLA | Customer queries always filter by `session['user_id']` |
| Session fixation | `session.clear()` before writing on login |
