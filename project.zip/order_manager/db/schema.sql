CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    role          TEXT    NOT NULL CHECK(role IN ('customer', 'manager', 'admin')),
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item        TEXT    NOT NULL,
    quantity    INTEGER NOT NULL CHECK(quantity >= 1 AND quantity <= 1000),
    status      TEXT    NOT NULL DEFAULT 'pending'
                        CHECK(status IN ('pending', 'shipped', 'delivered', 'cancelled')),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);
