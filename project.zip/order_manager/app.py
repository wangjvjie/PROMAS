import os
import sqlite3
import functools
from flask import (
    Flask, g, session, request, redirect, url_for,
    render_template, flash, abort
)
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', os.urandom(32))
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['WTF_CSRF_ENABLED'] = True

csrf = CSRFProtect(app)

DATABASE = os.path.join(os.path.dirname(__file__), 'db', 'orders.db')
ALLOWED_STATUSES = {'pending', 'shipped', 'delivered', 'cancelled'}


# ── Database helpers ──────────────────────────────────────────────────────────

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    os.makedirs(os.path.dirname(DATABASE), exist_ok=True)
    schema = os.path.join(os.path.dirname(__file__), 'db', 'schema.sql')
    with sqlite3.connect(DATABASE) as conn:
        conn.row_factory = sqlite3.Row
        with open(schema) as f:
            conn.executescript(f.read())
        # Seed a default admin if none exists
        existing = conn.execute(
            "SELECT id FROM users WHERE role = 'admin' LIMIT 1"
        ).fetchone()
        if not existing:
            conn.execute(
                "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                ('admin', generate_password_hash('Admin1234!'), 'admin')
            )
            conn.commit()


# ── Auth decorator ────────────────────────────────────────────────────────────

def require_role(*roles):
    """Decorator — re-fetches role from DB on every request; never trusts session alone."""
    def decorator(view_func):
        @functools.wraps(view_func)
        def wrapped(*args, **kwargs):
            user_id = session.get('user_id')
            if not user_id:
                return redirect(url_for('login'))
            db = get_db()
            user = db.execute(
                "SELECT role FROM users WHERE id = ?", (user_id,)
            ).fetchone()
            if not user or user['role'] not in roles:
                abort(403)
            return view_func(*args, **kwargs)
        return wrapped
    return decorator


def current_user():
    user_id = session.get('user_id')
    if not user_id:
        return None
    return get_db().execute(
        "SELECT id, username, role FROM users WHERE id = ?", (user_id,)
    ).fetchone()


# ── Auth routes ───────────────────────────────────────────────────────────────

@app.route('/')
def index():
    user = current_user()
    if not user:
        return redirect(url_for('login'))
    return redirect(url_for(f"{user['role']}_dashboard"))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        db = get_db()
        user = db.execute(
            "SELECT id, password_hash, role FROM users WHERE username = ?",
            (username,)
        ).fetchone()
        # Generic message to avoid username enumeration (T2)
        if not user or not check_password_hash(user['password_hash'], password):
            flash('Invalid username or password.', 'error')
            return render_template('login.html')
        # Session fixation prevention (T3)
        session.clear()
        session['user_id'] = user['id']
        session['role'] = user['role']
        return redirect(url_for(f"{user['role']}_dashboard"))
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        if not username or len(username) > 64:
            flash('Username must be 1–64 characters.', 'error')
            return render_template('register.html')
        if len(password) < 8:
            flash('Password must be at least 8 characters.', 'error')
            return render_template('register.html')
        # Role is NEVER taken from POST (T4)
        role = 'customer'
        db = get_db()
        try:
            db.execute(
                "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                (username, generate_password_hash(password), role)
            )
            db.commit()
        except sqlite3.IntegrityError:
            flash('Username already taken.', 'error')
            return render_template('register.html')
        flash('Account created! Please log in.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return redirect(url_for('login'))


# ── Customer dashboard ────────────────────────────────────────────────────────

CUSTOMER_PAGES = {'orders', 'place_order'}

@app.route('/dashboard/customer', methods=['GET', 'POST'])
@require_role('customer')
def customer_dashboard():
    page = request.args.get('page', 'orders')
    if page not in CUSTOMER_PAGES:
        page = 'orders'

    db = get_db()
    user_id = session['user_id']
    message = None

    if page == 'place_order' and request.method == 'POST':
        item = request.form.get('item', '').strip()
        try:
            quantity = int(request.form.get('quantity', 0))
        except ValueError:
            quantity = 0
        if not item or len(item) > 256:
            flash('Item name must be 1–256 characters.', 'error')
        elif quantity < 1 or quantity > 1000:
            flash('Quantity must be between 1 and 1000.', 'error')
        else:
            db.execute(
                "INSERT INTO orders (customer_id, item, quantity) VALUES (?, ?, ?)",
                (user_id, item, quantity)
            )
            db.commit()
            flash('Order placed successfully!', 'success')
            return redirect(url_for('customer_dashboard', page='orders'))

    # BOLA: always filter by user_id (T13 / T10)
    orders = db.execute(
        "SELECT id, item, quantity, status, created_at FROM orders "
        "WHERE customer_id = ? ORDER BY created_at DESC",
        (user_id,)
    ).fetchall()

    return render_template('customer_dashboard.html',
                           page=page, orders=orders)


# ── Manager dashboard ─────────────────────────────────────────────────────────

MANAGER_PAGES = {'orders', 'update_status'}

@app.route('/dashboard/manager', methods=['GET', 'POST'])
@require_role('manager')
def manager_dashboard():
    page = request.args.get('page', 'orders')
    if page not in MANAGER_PAGES:
        page = 'orders'

    db = get_db()

    if request.method == 'POST' and page == 'update_status':
        try:
            order_id = int(request.form.get('order_id', 0))
        except ValueError:
            order_id = 0
        status = request.form.get('status', '').strip()
        # Validate status against allowlist (T15)
        if status not in ALLOWED_STATUSES:
            flash('Invalid status value.', 'error')
        elif order_id < 1:
            flash('Invalid order ID.', 'error')
        else:
            db.execute(
                "UPDATE orders SET status = ? WHERE id = ?",
                (status, order_id)
            )
            db.commit()
            flash('Order status updated.', 'success')
        return redirect(url_for('manager_dashboard', page='orders'))

    orders = db.execute(
        "SELECT o.id, u.username, o.item, o.quantity, o.status, o.created_at "
        "FROM orders o JOIN users u ON o.customer_id = u.id "
        "ORDER BY o.created_at DESC"
    ).fetchall()

    return render_template('manager_dashboard.html',
                           page=page, orders=orders,
                           allowed_statuses=sorted(ALLOWED_STATUSES))


# ── Admin dashboard ───────────────────────────────────────────────────────────

ADMIN_PAGES = {'users', 'orders', 'create_user'}

@app.route('/dashboard/admin', methods=['GET', 'POST'])
@require_role('admin')
def admin_dashboard():
    page = request.args.get('page', 'users')
    if page not in ADMIN_PAGES:
        page = 'users'

    db = get_db()
    admin_id = session['user_id']

    if request.method == 'POST':
        action = request.form.get('action', '')

        if action == 'delete_user':
            try:
                uid = int(request.form.get('user_id', 0))
            except ValueError:
                uid = 0
            # Prevent self-deletion (T18)
            if uid == admin_id:
                flash('You cannot delete your own account.', 'error')
            elif uid < 1:
                flash('Invalid user ID.', 'error')
            else:
                db.execute("DELETE FROM users WHERE id = ?", (uid,))
                db.commit()
                flash('User deleted.', 'success')
            return redirect(url_for('admin_dashboard', page='users'))

        elif action == 'delete_order':
            try:
                oid = int(request.form.get('order_id', 0))
            except ValueError:
                oid = 0
            if oid < 1:
                flash('Invalid order ID.', 'error')
            else:
                db.execute("DELETE FROM orders WHERE id = ?", (oid,))
                db.commit()
                flash('Order deleted.', 'success')
            return redirect(url_for('admin_dashboard', page='orders'))

        elif action == 'create_user':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            # Admin can only create customer or manager — not another admin (T20)
            role = request.form.get('role', '')
            if role not in ('customer', 'manager'):
                flash('Invalid role.', 'error')
                return redirect(url_for('admin_dashboard', page='create_user'))
            if not username or len(username) > 64:
                flash('Username must be 1–64 characters.', 'error')
                return redirect(url_for('admin_dashboard', page='create_user'))
            if len(password) < 8:
                flash('Password must be at least 8 characters.', 'error')
                return redirect(url_for('admin_dashboard', page='create_user'))
            try:
                db.execute(
                    "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                    (username, generate_password_hash(password), role)
                )
                db.commit()
                flash(f'User "{username}" created as {role}.', 'success')
            except sqlite3.IntegrityError:
                flash('Username already taken.', 'error')
            return redirect(url_for('admin_dashboard', page='users'))

    users = db.execute(
        "SELECT id, username, role, created_at FROM users ORDER BY created_at DESC"
    ).fetchall()
    orders = db.execute(
        "SELECT o.id, u.username, o.item, o.quantity, o.status, o.created_at "
        "FROM orders o JOIN users u ON o.customer_id = u.id "
        "ORDER BY o.created_at DESC"
    ).fetchall()

    return render_template('admin_dashboard.html',
                           page=page, users=users, orders=orders,
                           admin_id=admin_id,
                           allowed_statuses=sorted(ALLOWED_STATUSES))


# ── Error handlers ────────────────────────────────────────────────────────────

@app.errorhandler(403)
def forbidden(e):
    return render_template('error.html', code=403,
                           message='You do not have permission to access this page.'), 403


@app.errorhandler(404)
def not_found(e):
    return render_template('error.html', code=404,
                           message='Page not found.'), 404


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    init_db()
    app.run(debug=False, host='0.0.0.0', port=5000)
