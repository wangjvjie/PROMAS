# Threat Model — Multi-Role Order Manager

## 1. Global Security Context

**Trust Boundaries**
- HTTP request body (`request.form`) — fully untrusted
- URL parameters (`request.args`) — untrusted, drive sub-page routing
- Flask session cookie — integrity-protected by HMAC but readable by client; role must be re-verified from DB
- SQLite database — trusted once written, but all inputs entering it must be parameterised
- `werkzeug` password hashing layer — trusted stdlib component

**Key Assets**
- User credentials (password hashes in `users` table)
- Order data (business-sensitive, ownership-restricted)
- Admin account — full system control
- Flask `SECRET_KEY` — compromise allows session forgery

**Auth / Privilege Model**
- Three roles: `customer < manager < admin`
- Roles stored in DB; session holds `user_id` + `role` as a cache only
- Every protected route re-fetches the user record from DB before acting
- Customers can only read/modify their own orders (BOLA guard)
- Managers can read all orders, update status only
- Admins can read/delete all orders and manage users, but cannot delete themselves

---

## 2. Function-Level Threats

### Function: `app.py:login()`
*Role*: Authenticates users and establishes session  
*Untrusted inputs*: `request.form['username']`, `request.form['password']`  
*Security-relevant operations*: `check_password_hash`, `session` write  
*Threats*:
- **T1: SQL Injection (CWE-89)** — If `username` is interpolated into a query string, attacker supplies `' OR 1=1 --` to bypass authentication
- **T2: Username enumeration** — Returning "username not found" vs "wrong password" as distinct messages lets attackers enumerate valid usernames
- **T3: Session fixation** — Reusing the same session ID before and after login lets an attacker pre-set a known session ID and hijack it after the victim logs in

*Protections*:
- Parameterised query: `db.execute("SELECT … WHERE username = ?", (username,))`
- Single generic error message: "Invalid username or password"
- Call `session.clear()` then regenerate before writing new session values

---

### Function: `app.py:register()`
*Role*: Creates new customer accounts  
*Untrusted inputs*: `request.form['username']`, `request.form['password']`  
*Security-relevant operations*: `generate_password_hash`, `INSERT INTO users`  
*Threats*:
- **T4: Privilege escalation via role injection (CWE-862)** — If `role` is read from `request.form`, an attacker POSTs `role=admin` to self-register as admin
- **T5: SQL Injection (CWE-89)** — Username interpolated into INSERT
- **T6: Weak password accepted** — No minimum length; attacker registers accounts with empty passwords, then brute-forces or credential-stuffs other accounts

*Protections*:
- Role hardcoded server-side: `role = 'customer'` — never from POST
- Parameterised INSERT
- Enforce minimum password length (≥8 chars) server-side

---

### Function: `app.py:require_role()` (decorator)
*Role*: Guards every dashboard route against unauthorised access  
*Untrusted inputs*: `session['user_id']`, `session['role']`  
*Security-relevant operations*: Role comparison, DB re-fetch  
*Threats*:
- **T7: Broken Access Control (CWE-862)** — Trusting `session['role']` without DB re-fetch allows a user whose role was downgraded to retain elevated access until session expires
- **T8: Missing function-level access control (CWE-306)** — If the decorator is accidentally omitted from a route, the route becomes publicly accessible
- **T9: Insecure Direct Object Reference** — A customer manually navigates to `/dashboard/admin?page=users` and accesses admin functions if role guard is insufficient

*Protections*:
- Always re-query `SELECT role FROM users WHERE id = ?` inside the decorator
- Return HTTP 403 (not redirect) for authenticated but wrong-role requests
- Apply decorator to 100% of protected routes; test with automated route listing

---

### Function: `app.py:customer_dashboard()` — place_order sub-page
*Role*: Accepts order placement from authenticated customers  
*Untrusted inputs*: `request.form['item']`, `request.form['quantity']`, `?page=` URL param  
*Security-relevant operations*: `INSERT INTO orders`, page routing via `?page=`  
*Threats*:
- **T10: SQL Injection (CWE-89)** — `item` or `quantity` interpolated into INSERT
- **T11: Path traversal via page parameter (CWE-22)** — `?page=../../etc/passwd` if `page` is used in a file path or passed unsanitised
- **T12: Integer overflow / invalid quantity (CWE-20)** — `quantity=-999` or `quantity=99999999` accepted without validation
- **T13: CSRF — forged order placement (CWE-352)** — Attacker hosts a page that silently POSTs to `/dashboard/customer` placing an order on the victim's behalf

*Protections*:
- Parameterised INSERT
- `?page=` resolved via allowlist dict: `{'orders': ..., 'place_order': ...}` — not used in file paths
- Validate `quantity`: must be integer, 1 ≤ quantity ≤ 1000
- Flask-WTF CSRF token on all forms

---

### Function: `app.py:manager_dashboard()` — update_status sub-page
*Role*: Allows managers to change order status  
*Untrusted inputs*: `request.form['order_id']`, `request.form['status']`  
*Security-relevant operations*: `UPDATE orders SET status = ? WHERE id = ?`  
*Threats*:
- **T14: SQL Injection (CWE-89)** — `status` interpolated into UPDATE
- **T15: Unauthorised status value** — Manager sets `status='superadmin_override'` or other arbitrary string bypassing business logic
- **T16: Insecure Direct Object Reference (CWE-862)** — Manager updates an order belonging to a customer they should not interact with (less critical here since managers see all, but still noteworthy)
- **T17: CSRF — forged status update (CWE-352)** — Attacker tricks a logged-in manager into submitting a forged status change

*Protections*:
- Parameterised UPDATE
- Validate `status` against allowlist: `{'pending', 'shipped', 'delivered', 'cancelled'}`
- Flask-WTF CSRF on the status-update form

---

### Function: `app.py:admin_dashboard()` — user delete / order delete sub-pages
*Role*: Admin CRUD on users and orders  
*Untrusted inputs*: `request.form['user_id']`, `request.form['order_id']`, `?page=`  
*Security-relevant operations*: `DELETE FROM users`, `DELETE FROM orders`  
*Threats*:
- **T18: Admin self-deletion** — Admin deletes own account, leaving the system without any admin
- **T19: SQL Injection (CWE-89)** — `user_id` or `order_id` interpolated into DELETE
- **T20: Privilege escalation — admin creates another admin (CWE-862)** — If the create-user form exposes a role dropdown, an attacker who gains access to the admin session creates additional admin accounts
- **T21: CSRF — forged admin delete (CWE-352)** — Attacker tricks admin into deleting a user or order

*Protections*:
- Check `user_id != session['user_id']` before executing DELETE on users
- Parameterised DELETE
- Role dropdown in create-user form limited to `['customer', 'manager']` — admin cannot create another admin via the web UI
- Flask-WTF CSRF on all admin forms

---

## 3. Project Integrity

**Critical Risks**

1. **Weak `SECRET_KEY`** — Flask signs session cookies with `SECRET_KEY`. A guessable key (e.g. `"dev"`, `"secret"`) allows an attacker to forge session cookies and impersonate any user including admin.  
   *Mitigation*: Generate with `python -c "import secrets; print(secrets.token_hex(32))"` and store in environment variable, never in source code.

2. **SQLite file world-readable** — If `orders.db` is placed inside the web-served directory, it can be downloaded directly.  
   *Mitigation*: Store DB file outside the Flask static folder; default path `./db/orders.db` is not served by Flask's static handler.

3. **Missing CSRF on logout** — A CSRF attack against GET `/logout` can force a victim to log out (session teardown DoS).  
   *Mitigation*: Make logout a POST with CSRF token, or at minimum verify `Referer` header.

**Top 3 Attack Vectors**
1. Register with `role=admin` in POST body → instant admin access (T4)
2. `?page=` parameter not allowlist-validated → path traversal or logic bypass (T11)
3. Weak `SECRET_KEY` in production → session cookie forgery → any account takeover

**Recommended Additions**
- Rate-limit `/login` (e.g. 10 attempts/min per IP) to prevent brute-force
- Log all admin actions (user delete, order delete) to an audit table
- Add `Secure; HttpOnly; SameSite=Strict` flags to the session cookie via `SESSION_COOKIE_*` Flask config
