"""
Gunicorn WSGI HTTP server configuration for production deployment.

This module defines worker processes, binding address, request timeouts,
and logging behavior for the Ping tool Flask application.
"""

import multiprocessing
import os

# Server Socket
bind = os.getenv("GUNICORN_BIND", "0.0.0.0:5000")

# Worker Processes
workers = int(os.getenv("GUNICORN_WORKERS", multiprocessing.cpu_count() * 2 + 1))
worker_class = "sync"
worker_connections = 1000
timeout = int(os.getenv("GUNICORN_TIMEOUT", 30))
keepalive = 2

# Logging
accesslog = os.getenv("GUNICORN_ACCESS_LOG", "-")
errorlog = os.getenv("GUNICORN_ERROR_LOG", "-")
loglevel = os.getenv("GUNICORN_LOG_LEVEL", "info")
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# Process Naming
proc_name = "ping-tool"

# Security & Hardening
limit_request_line = 4094
limit_request_fields = 100
limit_request_field_size = 8190

# Graceful Timeout
graceful_timeout = 30

# Preload Application
preload_app = True

# Application Entry Point
# Format: module_name:variable_name
wsgi_app = "app:create_app()"
