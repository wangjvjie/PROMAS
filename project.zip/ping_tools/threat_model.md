### 1. Global Security Context
- **Trust boundaries:** 
  - `Client Browser ↔ Nginx/Reverse Proxy` (TLS termination, header injection, rate limiting)
  - `Nginx ↔ Flask/Gunicorn` (WSGI boundary, payload routing)
  - `Flask ↔ OS Subprocess (ping)` (Process creation, capability boundary)
  - `Subprocess ↔ External Network` (ICMP egress, DNS resolution)
  Untrusted input enters exclusively at `POST /ping` (form payload, headers, cookies).
- **Key assets to protect:** 
  - Host OS integrity (prevent RCE/container escape)
  - Internal network topology & cloud metadata (prevent SSRF/recon)
  - Application availability (prevent DoS/resource exhaustion)
  - User session/data (minimal here, but template rendering must prevent XSS)
- **Authentication/authorization model:** 
  - Public/unauthenticated tool. Security relies on defense-in-depth: strict input allowlisting, IP-based rate limiting, network egress controls, and process isolation. No RBAC or session state.

### 2. Function-level Threats

### Function: `app.py:ping()`
- **Role in the system:** Entry point for form submission; extracts payload, applies rate limiting, delegates to validator/service, and renders response.
- **Untrusted inputs / external sources:** HTTP POST body (`target`), custom headers, cookies, proxy-forwarded IPs, concurrent request streams.
- **Security-relevant operations:** Request parsing, rate-limit enforcement, routing, error handling, template response generation.
- **Potential threats:**
  - T1: Command Injection — Malformed or bypassed validation reaches subprocess execution.
  - T2: Denial of Service (Worker Exhaustion) — High concurrency or slowloris-style requests starving Gunicorn workers.
  - T3: SSRF / Internal Network Mapping — Targeting `127.0.0.1`, `10.0.0.0/8`, `169.254.169.254` to probe internal infrastructure.
  - T4: Rate Limit Bypass — IPv6 rotation, proxy chaining, or `X-Forwarded-For` spoofing to evade throttling.
- **Recommended protections (high-level):** Enforce strict allowlist validation before routing; block RFC 1918, loopback, link-local, and cloud metadata ranges; implement token-bucket rate limiting keyed on verified client IP (strip proxy headers via trusted proxy config); use async task queue or connection pooling for heavy loads; return generic HTTP 429/400 without stack traces.

### Function: `validators.py:validate_target()`
- **Role in the system:** Gatekeeper enforcing strict format compliance for IPv4, IPv6, and RFC 1123 hostnames.
- **Untrusted inputs / external sources:** Raw string from HTTP request body.
- **Security-relevant operations:** Regex compilation/matching, string normalization, exception raising.
- **Potential threats:**
  - T1: ReDoS (Regex Denial of Service) — Catastrophic backtracking on crafted strings exhausting CPU.
  - T2: Validation Bypass — Incomplete character allowlists permitting shell metacharacters (`;`, `|`, `&`, `$`, `` ` ``), whitespace, or Unicode homoglyphs.
  - T3: Logic/Normalization Flaw — Accepting trailing dots, percent-encoding, or IDN punycode that resolves to internal hosts.
  - T4: Exception Leakage — Verbose `ValueError` messages exposing regex patterns or internal logic.
- **Recommended protections (high-level):** Use anchored, compiled regexes with strict character classes (`^[a-zA-Z0-9.-]+$`); enforce max length (≤253 chars); normalize Unicode/IDN before matching; reject control characters, whitespace, and percent-encoded payloads; catch and log validation failures generically; consider `regex` module with timeout support if complex patterns are unavoidable.

### Function: `ping_service.py:PingService.execute()`
- **Role in the system:** Orchestrates safe subprocess execution, captures I/O, handles timeouts/errors, and sanitizes output.
- **Untrusted inputs / external sources:** Pre-validated target string, OS environment, DNS resolver state.
- **Security-relevant operations:** `subprocess.run()` (process spawn), stdout/stderr capture, `markupsafe.escape()`, timeout/error handling.
- **Potential threats:**
  - T1: Privilege Escalation / Container Escape — Exploiting `ping` binary (often SUID) or missing capability restrictions to gain host access.
  - T2: Output Injection / XSS — Unescaped ping output containing HTML/JS or ANSI escape sequences rendered in browser.
  - T3: Resource Exhaustion / Fork Bomb — Rapid process spawning exhausting PIDs, memory, or file descriptors if limits misconfigured.
  - T4: Information Disclosure — Ping output leaking internal DNS servers, OS fingerprints, routing tables, or network topology.
- **Recommended protections (high-level):** Enforce `shell=False` with explicit list args; drop all Linux capabilities except `CAP_NET_RAW`; run as non-root with strict `ulimit`/cgroups (CPU, memory, PID, open files); enforce hard execution timeout; strip ANSI codes and escape all output via `markupsafe.escape()`; run in ephemeral container with read-only root FS and explicit writable `/tmp`.

### Function: `templates/index.html` (Jinja2 Rendering Context)
- **Role in the system:** Presents input form, displays sanitized results, and surfaces validation/execution errors.
- **Untrusted inputs / external sources:** Escaped ping output, error strings, echoed user input.
- **Security-relevant operations:** Jinja2 template rendering, auto-escaping, DOM construction.
- **Potential threats:**
  - T1: Reflected/Stored XSS — Bypassing auto-escaping via `|safe` filter, raw HTML injection, or DOM-based sinks.
  - T2: Server-Side Template Injection (SSTI) — User input interpolated into Jinja2 syntax (`{{ }}`, `{% %}`) if rendering context is misconfigured.
  - T3: Clickjacking / UI Redressing — Missing frame restrictions or weak CSP allowing malicious embedding.
- **Recommended protections (high-level):** Rely on Jinja2 auto-escaping (never disable globally); strictly avoid `|safe` on dynamic content; render errors as plain text blocks; enforce strict Content-Security-Policy (`default-src 'self'`, `script-src 'none'`); add `X-Frame-Options: DENY` and `X-Content-Type-Options: nosniff` via reverse proxy.

### 3. Project Integrity
- **Module consistency and import chains:** Linear dependency graph (`app.py` → `ping_service.py` → `validators.py`). No circular imports. `__init__.py` barrel exports are safe but should avoid wildcard imports (`from . import *`) to prevent namespace pollution. Ensure `ping_service` does not re-import `app` to avoid Flask context coupling.
- **Dependency completeness:** `requirements.txt` must pin exact versions of `Flask`, `markupsafe`, `python-dotenv`, `flask-limiter`, and `gunicorn`. Base Docker image must explicitly install `iputils-ping` (Debian/Ubuntu) or `iputils` (Alpine). Missing `CAP_NET_RAW` in container runtime will cause silent `ping` failures; must be declared in `docker-compose.yml` (`cap_add: [NET_RAW]`).
- **Install → build → start correctness:** 
  - `pip install -r requirements.txt` succeeds in clean venv.
  - `docker build` must use multi-stage or slim base, create non-root user, set `USER appuser`, and mark root FS read-only except `/tmp` and `/dev/shm`.
  - `gunicorn` binds to `0.0.0.0:5000` behind Nginx; Nginx must strip untrusted headers, enforce HTTPS/HSTS, and proxy to Gunicorn via `proxy_pass`.
  - Startup sequence: `.env` loads → Flask app factory initializes rate limiter → Gunicorn spawns workers → Nginx routes traffic. Health checks should verify `/` returns 200 without executing `ping`.