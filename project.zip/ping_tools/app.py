"""Main Flask application entry point handling routing, environment configuration, rate limiting, input validation integration, and secure ping execution."""

import os
import logging
from typing import Dict

from flask import Flask, request, render_template, Response
from dotenv import load_dotenv
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from validators import validate_target
from ping_service import PingService

# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


def create_app() -> Flask:
    """Factory function that initializes the Flask application, loads .env configuration, configures rate limiting middleware, and registers route handlers."""
    app = Flask(__name__)

    # Load configuration from environment
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "fallback-dev-key")
    app.config["FLASK_ENV"] = os.getenv("FLASK_ENV", "development")

    # Initialize rate limiter
    rate_limit_default = os.getenv("RATE_LIMIT", "5/minute")
    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        default_limits=[rate_limit_default],
        storage_uri="memory://"
    )

    # Register security headers on every response
    @app.after_request
    def add_security_headers(response: Response) -> Response:
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        return response

    # Register routes
    app.add_url_rule("/", view_func=index, methods=["GET"])
    app.add_url_rule("/ping", view_func=ping, methods=["POST"])

    # Apply rate limiting specifically to the ping endpoint
    limiter.limit(rate_limit_default)(ping)

    return app


def index() -> str:
    """Handles GET requests to the root path and renders the ping input form template."""
    return render_template("index.html")


def ping() -> str:
    """Handles POST requests, extracts and validates the target using validators.py, executes the ping command via ping_service.py, sanitizes output with markupsafe, and returns the result or error to the template."""
    target = request.form.get("target", "").strip()
    error = None
    result = None

    if not target:
        error = "Please enter a hostname or IP address."
        return render_template("index.html", target=target, error=error, result=result)

    try:
        # Validate target (raises ValueError if invalid)
        validated_target = validate_target(target)
    except ValueError as e:
        logger.warning("Validation failed for input: %s", target)
        error = "Invalid target format. Please enter a valid public IPv4, IPv6, or hostname."
        return render_template("index.html", target=target, error=error, result=result)

    # Initialize ping service with environment-configured limits
    packet_count = int(os.getenv("PING_PACKET_COUNT", "3"))
    timeout_seconds = int(os.getenv("PING_TIMEOUT", "10"))
    service = PingService(packet_count=packet_count, timeout_seconds=timeout_seconds)

    # Execute ping
    ping_result: Dict[str, str] = service.execute(validated_target)

    if ping_result["status"] == "error":
        error = ping_result["output"]
    else:
        result = {
            "status": ping_result["status"],
            "output": ping_result["output"],
            "target": validated_target
        }

    return render_template("index.html", target=target, error=error, result=result)


# Allow running directly for development
if __name__ == "__main__":
    app = create_app()
    port = int(os.getenv("PORT", "5000"))
    debug = os.getenv("FLASK_ENV") == "development"
    logger.info("Starting Flask development server on port %d", port)
    app.run(host="0.0.0.0", port=port, debug=debug)
