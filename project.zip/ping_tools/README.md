# Secure Ping Web Tool

A lightweight, security-hardened web application that allows users to ping a hostname or IP address directly from their browser. Built with Python, Flask, and strict defense-in-depth principles.

## 📋 Features

- **Web-based ping interface**: Enter a hostname or IP address and view results instantly
- **Strict input validation**: IPv4, IPv6, and RFC 1123 hostname regex enforcement
- **Command injection prevention**: `subprocess.run()` with `shell=False` and explicit argument lists
- **Rate limiting**: IP-based throttling to prevent abuse (configurable, default: 5 req/min)
- **Output sanitization**: All ping output escaped via `markupsafe` to prevent XSS
- **Container-ready**: Dockerized with non-root user, read-only filesystem, and minimal base image
- **Production-ready**: Gunicorn WSGI server + Nginx reverse proxy with HTTPS/HSTS

## 🏗️ Architecture

```
Client Browser
    ↓ (HTTPS)
Nginx (Reverse Proxy + TLS Termination + Security Headers)
    ↓ (HTTP/WSGI)
Gunicorn (WSGI Server + Worker Management)
    ↓
Flask App (Routing + Rate Limiting + Validation)
    ↓
PingService (subprocess.run with shell=False)
    ↓
OS ping binary (ICMP execution)
```

### Key Components

| File | Purpose |
|------|---------|
| `app.py` | Flask application factory, routes, rate limiting |
| `validators.py` | Strict regex validation for IPv4, IPv6, hostnames |
| `ping_service.py` | Safe subprocess execution, timeout handling, output sanitization |
| `templates/index.html` | Responsive Jinja2 form with auto-escaping |
| `gunicorn.conf.py` | Production WSGI server configuration |
| `nginx.conf` | Reverse proxy, HTTPS, security headers |
| `Dockerfile` | Minimal container build with non-root user |
| `docker-compose.yml` | Container orchestration with security constraints |

## 🚀 Quick Start

### Prerequisites

- Python 3.10+
- `ping` utility installed (usually pre-installed on Linux/macOS)

### Local Development

```bash
# 1. Clone and enter the project directory
git clone <repository-url>
cd secure-ping-tool

# 2. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment variables (optional, defaults provided)
cp .env.example .env  # Edit as needed

# 5. Run the development server
python app.py
```

The app will be available at `http://localhost:5000`.

### Docker Deployment

```bash
# Build and run with docker-compose
docker-compose up --build

# Or build and run manually
docker build -t secure-ping .
docker run --cap-add=NET_RAW -p 5000:5000 secure-ping
```

> **Note**: The `NET_RAW` capability is required for the `ping` command to function inside the container.

## 🔒 Security Design

This tool follows defense-in-depth principles to safely expose network diagnostics via the web:

### Input Validation
- Strict regex patterns for IPv4 (`^(\d{1,3}\.){3}\d{1,3}$`), IPv6, and RFC 1123 hostnames
- Maximum length enforcement (≤253 characters)
- Rejection of shell metacharacters, whitespace, control characters, and percent-encoding
- Generic error messages to prevent information leakage

### Command Execution
- `subprocess.run()` with `shell=False` and explicit list arguments
- Hard execution timeout (configurable, default: 10 seconds)
- Packet count limits (1–3 packets)
- Graceful handling of `TimeoutExpired` and `CalledProcessError`

### Output Sanitization
- All stdout/stderr escaped via `markupsafe.escape()` before rendering
- Jinja2 auto-escaping enabled globally
- No `|safe` filter used on dynamic content

### Rate Limiting & Availability
- IP-based rate limiting (default: 5 requests/minute)
- Gunicorn worker timeouts to prevent slowloris attacks
- Generic HTTP 429/400 responses without stack traces

### Container Hardening
- Non-root user execution (`appuser`)
- Read-only root filesystem with writable `/tmp` and `/dev/shm`
- Minimal base image (`python:3.11-slim`)
- Dropped Linux capabilities except `CAP_NET_RAW`
- No interactive shell access

## ⚙️ Configuration

Environment variables (`.env`):

| Variable | Default | Description |
|----------|---------|-------------|
| `FLASK_ENV` | `production` | Flask environment mode |
| `SECRET_KEY` | *(required)* | Flask session/CSRF secret |
| `RATE_LIMIT` | `5 per minute` | Rate limit for ping endpoint |
| `PING_PACKETS` | `3` | Number of ping packets (1–3) |
| `PING_TIMEOUT` | `10` | Execution timeout in seconds |
| `GUNICORN_WORKERS` | `2` | Number of Gunicorn worker processes |

## 🌐 Production Deployment

### Gunicorn

```bash
gunicorn -c gunicorn.conf.py app:create_app
```

Binds to `0.0.0.0:5000` with configurable workers and timeouts.

### Nginx Reverse Proxy

Place `nginx.conf` in your Nginx configuration directory:

```bash
sudo cp nginx.conf /etc/nginx/sites-available/secure-ping
sudo ln -s /etc/nginx/sites-available/secure-ping /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

Nginx handles:
- HTTPS termination with Let's Encrypt (configure separately)
- HSTS and security headers
- Request size limits
- Proxy routing to Gunicorn
- Additional rate limiting

### Systemd Service (Optional)

```ini
[Unit]
Description=Secure Ping Web Tool
After=network.target

[Service]
User=appuser
Group=appuser
WorkingDirectory=/opt/secure-ping
Environment="PATH=/opt/secure-ping/venv/bin"
ExecStart=/opt/secure-ping/venv/bin/gunicorn -c gunicorn.conf.py app:create_app
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

## 📁 Project Structure

```
.
├── app.py                  # Flask application entry point
├── validators.py           # Input validation module
├── ping_service.py         # Ping execution service
├── __init__.py             # Package barrel exports
├── templates/
│   └── index.html          # Web form template
├── requirements.txt        # Python dependencies
├── .env                    # Runtime configuration
├── .gitignore              # Git exclusions
├── .dockerignore           # Docker build exclusions
├── Dockerfile              # Container build definition
├── docker-compose.yml      # Container orchestration
├── gunicorn.conf.py        # WSGI server config
├── nginx.conf              # Reverse proxy config
└── README.md               # This file
```

## 🧪 Testing

Run the validation and ping service manually:

```python
from validators import validate_target
from ping_service import PingService

# Test validation
print(validate_target("8.8.8.8"))        # ✅ Valid IPv4
print(validate_target("google.com"))     # ✅ Valid hostname
print(validate_target("127.0.0.1"))      # ❌ Blocked (loopback)

# Test ping execution
service = PingService(packet_count=3, timeout_seconds=10)
result = service.execute("8.8.8.8")
print(result["status"])   # "success" or "error"
print(result["output"])   # Sanitized ping output
```

## ⚠️ Security Considerations

- **No authentication**: This is a public tool. Deploy behind authentication if internal use only.
- **Network exposure**: Ensure the container/host has appropriate egress firewall rules.
- **Cloud metadata**: Loopback, RFC 1918, link-local, and `169.254.169.254` ranges are blocked by default.
- **Monitoring**: Log failed validation attempts and rate limit hits for abuse detection.
- **Updates**: Regularly update base images and Python dependencies for security patches.

## 📄 License

MIT License. See LICENSE file for details.
