"""Core service for safely executing ping commands via subprocess, capturing output, handling timeouts/errors, and sanitizing results for web display."""

import subprocess
import logging
import re
from typing import Dict

from markupsafe import escape
from validators import validate_target

logger = logging.getLogger(__name__)

# Regex to strip ANSI escape codes from terminal output
_ANSI_ESCAPE_RE = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')


class PingService:
    """Safely executes ping commands with configurable limits and sanitizes output."""

    def __init__(self, packet_count: int, timeout_seconds: int) -> None:
        """Initializes the service with configurable packet count (1-3) and execution timeout limits.

        Args:
            packet_count: Number of ICMP packets to send (clamped to 1-3).
            timeout_seconds: Maximum seconds to wait for ping completion.
        """
        # Clamp packet count to safe range
        self.packet_count = max(1, min(3, packet_count))
        self.timeout_seconds = max(1, timeout_seconds)

    def execute(self, target: str) -> Dict[str, str]:
        """Validates the target, executes ping via subprocess.run with shell=False, captures stdout/stderr, handles TimeoutExpired/CalledProcessError, escapes output with markupsafe, and returns a dictionary with status and sanitized output.

        Args:
            target: Pre-validated hostname or IP address.

        Returns:
            Dictionary with 'status' ('success' or 'error') and 'output' (sanitized string).
        """
        # Validate target (raises ValueError if invalid)
        try:
            validated_target = validate_target(target)
        except ValueError as e:
            logger.warning("Validation failed for target: %s", target)
            return {"status": "error", "output": escape(str(e))}

        # Build explicit argument list (shell=False prevents injection)
        cmd = ["ping", "-c", str(self.packet_count), "-W", "2", validated_target]

        logger.info("Executing ping command: %s", " ".join(cmd))

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                shell=False,
                timeout=self.timeout_seconds
            )

            # Combine stdout and stderr
            raw_output = result.stdout
            if result.stderr:
                raw_output += "\n" + result.stderr if raw_output else result.stderr

            # Strip ANSI escape codes
            clean_output = _ANSI_ESCAPE_RE.sub('', raw_output)

            # Escape for safe HTML rendering
            sanitized_output = escape(clean_output)

            if result.returncode == 0:
                return {"status": "success", "output": sanitized_output}
            else:
                return {
                    "status": "error",
                    "output": f"Host unreachable or ping failed (exit code {result.returncode})\n\n{sanitized_output}"
                }

        except subprocess.TimeoutExpired:
            logger.error("Ping timed out for target: %s", validated_target)
            return {
                "status": "error",
                "output": escape(f"Ping timed out after {self.timeout_seconds} seconds.")
            }
        except subprocess.CalledProcessError as e:
            logger.error("Ping process error for target %s: %s", validated_target, e)
            return {
                "status": "error",
                "output": escape(f"Command execution failed: {e}")
            }
        except FileNotFoundError:
            logger.error("ping binary not found in PATH")
            return {
                "status": "error",
                "output": escape("Ping command not available on this system.")
            }
        except Exception as e:
            logger.exception("Unexpected error during ping execution")
            return {
                "status": "error",
                "output": escape("An unexpected error occurred.")
            }
