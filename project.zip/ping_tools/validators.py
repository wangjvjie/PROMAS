"""Input validation module enforcing strict regex patterns for IPv4, IPv6, and RFC 1123 hostnames."""

import re
import ipaddress
import logging

logger = logging.getLogger(__name__)

# Maximum length for hostnames per RFC 1035
_MAX_TARGET_LENGTH = 253

# Compiled regex patterns (anchored, strict character classes to prevent ReDoS)
_IPV4_RE = re.compile(
    r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}'
    r'(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
)

_IPV6_RE = re.compile(
    r'^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$'
)

_HOSTNAME_RE = re.compile(
    r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+'
    r'[a-zA-Z]{2,}$'
)


def is_valid_ipv4(ip: str) -> bool:
    """Internal helper that checks if the input matches a strict IPv4 dotted-decimal format."""
    return bool(_IPV4_RE.match(ip))


def is_valid_ipv6(ip: str) -> bool:
    """Internal helper that checks if the input matches a valid IPv6 hexadecimal format."""
    return bool(_IPV6_RE.match(ip))


def _is_private_or_reserved(ip_str: str) -> bool:
    """Check if an IP address is private, loopback, link-local, or reserved."""
    try:
        addr = ipaddress.ip_address(ip_str)
        return addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved
    except ValueError:
        return False


def validate_target(target: str) -> str:
    """Validates the input string against IPv4, IPv6, and RFC-compliant hostname regex patterns.

    Returns the sanitized target or raises ValueError if invalid.
    """
    if not isinstance(target, str):
        raise ValueError("Invalid target format")

    target = target.strip()

    if len(target) == 0 or len(target) > _MAX_TARGET_LENGTH:
        raise ValueError("Invalid target format")

    # Reject control characters, whitespace, and shell metacharacters
    if re.search(r'[\s;|&$`\\\'\"<>(){}[\]!#~]', target):
        raise ValueError("Invalid target format")

    # Check IPv4
    if is_valid_ipv4(target):
        if _is_private_or_reserved(target):
            raise ValueError("Invalid target format")
        return target

    # Check IPv6
    if is_valid_ipv6(target):
        if _is_private_or_reserved(target):
            raise ValueError("Invalid target format")
        return target

    # Check RFC 1123 hostname
    if _HOSTNAME_RE.match(target):
        return target

    raise ValueError("Invalid target format")
