/*
 * parser.c — Image metadata parser implementation.
 *
 * Security notes embedded inline at each vulnerability site.
 * CWEs addressed: CWE-787, CWE-125, CWE-416, CWE-134, CWE-476.
 */

#include "parser.h"

#include <string.h>
#include <stdio.h>
#include <stdint.h>

/* ── Expected magic bytes ─────────────────────────────────────────────── */

static const uint8_t EXPECTED_MAGIC[4] = {
    MAGIC_0, MAGIC_1, MAGIC_2, MAGIC_3
};

/* ══════════════════════════════════════════════════════════════════════════
 * parse_header
 * ══════════════════════════════════════════════════════════════════════════ */

int parse_header(FILE *fp, ImageHeader *hdr)
{
    uint8_t raw[HEADER_SIZE];

    /*
     * T5 (CWE-125) — short file guard.
     * fread returns the number of ITEMS read. If the file is < 8 bytes, we
     * get a partial buffer.  Reading hdr fields from a partially-filled struct
     * would give us stale stack bytes as tag_count, potentially > MAX_TAGS.
     */
    if (fread(raw, 1, HEADER_SIZE, fp) != HEADER_SIZE) {
        fprintf(stderr, "[error] File too short to contain a valid header.\n");
        return -1;
    }

    /* Copy magic bytes */
    memcpy(hdr->magic, raw, 4);

    /*
     * T7 (CWE-20) — compare ALL 4 magic bytes, not just a prefix.
     */
    if (memcmp(hdr->magic, EXPECTED_MAGIC, 4) != 0) {
        fprintf(stderr,
            "[error] Bad magic: got %02X%02X%02X%02X, expected %02X%02X%02X%02X.\n",
            hdr->magic[0], hdr->magic[1], hdr->magic[2], hdr->magic[3],
            EXPECTED_MAGIC[0], EXPECTED_MAGIC[1], EXPECTED_MAGIC[2], EXPECTED_MAGIC[3]);
        return -1;
    }

    /* Little-endian uint16 decode (portable — avoids unaligned access UB) */
    hdr->version   = (uint16_t)(raw[4] | ((uint16_t)raw[5] << 8));
    hdr->tag_count = (uint16_t)(raw[6] | ((uint16_t)raw[7] << 8));

    /*
     * T6 (CWE-787) — clamp tag_count to MAX_TAGS BEFORE any loop.
     * A crafted header with tag_count=0xFFFF would otherwise drive the entry
     * loop 65535 iterations and write entries[32]..entries[65534] → stack smash.
     */
    if (hdr->tag_count > MAX_TAGS) {
        fprintf(stderr,
            "[warn] tag_count %u exceeds MAX_TAGS (%d); clamping.\n",
            hdr->tag_count, MAX_TAGS);
        hdr->tag_count = MAX_TAGS;
    }

    return 0;
}

/* ══════════════════════════════════════════════════════════════════════════
 * parse_entry
 * ══════════════════════════════════════════════════════════════════════════ */

int parse_entry(FILE *fp, MetaEntry *entry, int free_on_error)
{
    /*
     * Zero the entire struct so that:
     *  (a) value[] is guaranteed NUL-terminated even on partial reads (T3),
     *  (b) extra is NULL so free_result() is safe on uninitialised slots.
     */
    memset(entry, 0, sizeof(MetaEntry));

    /* Read tag_id (1 byte) */
    if (fread(&entry->tag_id, 1, 1, fp) != 1) {
        fprintf(stderr, "[error] Unexpected EOF reading tag_id.\n");
        goto fail;
    }

    /* Read length (1 byte) */
    if (fread(&entry->length, 1, 1, fp) != 1) {
        fprintf(stderr, "[error] Unexpected EOF reading length.\n");
        goto fail;
    }

    /*
     * T1 (CWE-787) — buffer overflow prevention.
     *
     * entry->length is uint8_t → max 255.
     * VALUE_BUF is 64.  Copying min(length, VALUE_BUF-1) bytes caps the write
     * to 63 bytes, leaving room for the mandatory NUL terminator at index 63.
     *
     * We must also consume the FULL `entry->length` bytes from the file so
     * the file pointer stays aligned for the next entry.
     */
    size_t copy_len = MIN((size_t)entry->length, (size_t)(VALUE_BUF - 1));
    size_t skip_len = (size_t)entry->length - copy_len;

    /* Read up to copy_len bytes into value[] */
    if (copy_len > 0) {
        if (fread(entry->value, 1, copy_len, fp) != copy_len) {
            fprintf(stderr,
                "[error] Unexpected EOF reading value for tag 0x%02X.\n",
                entry->tag_id);
            goto fail;
        }
    }

    /*
     * T2 (CWE-787) — NUL termination within bounds.
     * copy_len <= VALUE_BUF-1, so index copy_len is at most VALUE_BUF-1.
     */
    entry->value[copy_len] = '\0';

    /* Consume and discard the bytes that didn't fit (keep file position sane) */
    if (skip_len > 0) {
        if (fseek(fp, (long)skip_len, SEEK_CUR) != 0) {
            fprintf(stderr,
                "[warn] Could not skip %zu overflow bytes for tag 0x%02X.\n",
                skip_len, entry->tag_id);
            goto fail;
        }
    }

    /*
     * Allocate the optional annotation buffer.
     * In production this might store human-readable type names; here we use
     * it as the CWE-416 demonstration target.
     */
    entry->extra = (char *)malloc(32);
    if (entry->extra == NULL) {
        fprintf(stderr, "[error] malloc failed for tag 0x%02X annotation.\n",
                entry->tag_id);
        goto fail;
    }
    snprintf(entry->extra, 32, "tag=0x%02X len=%u", entry->tag_id, entry->length);

    return 0;

fail:
    /*
     * T4 (CWE-416) — use-after-free prevention in --free-on-error mode.
     *
     * We free entry->extra and IMMEDIATELY set it to NULL in the same block.
     * The caller (parse_image) may recycle this same MetaEntry slot for the
     * next iteration.  If extra were left as a dangling pointer, the next
     * call to parse_entry (which does memset → 0) would be safe, but the
     * window between goto fail and the next memset is the danger zone.
     *
     * Setting to NULL here ensures that any accidental read of extra before
     * the next memset produces a NULL dereference (detectable) rather than
     * a silent use-after-free (exploitable).
     */
    if (free_on_error && entry->extra != NULL) {
        free(entry->extra);
        entry->extra = NULL;    /* ← NULL immediately; no dangling pointer  */
    }

    return -1;
}

/* ══════════════════════════════════════════════════════════════════════════
 * parse_image
 * ══════════════════════════════════════════════════════════════════════════ */

int parse_image(FILE *fp, ParseResult *result, int free_on_error)
{
    /* Zero the entire result so extra pointers start NULL */
    memset(result, 0, sizeof(ParseResult));

    if (parse_header(fp, &result->header) != 0) {
        return -1;   /* fatal — nothing to recover from */
    }

    result->count = 0;

    for (uint16_t i = 0; i < result->header.tag_count; i++) {
        /*
         * Slot index is bounded by tag_count which was already clamped to
         * MAX_TAGS in parse_header (T6 guard).
         * i < tag_count <= MAX_TAGS, so entries[i] is always in-bounds.
         */
        MetaEntry *slot = &result->entries[result->count];

        if (parse_entry(fp, slot, free_on_error) != 0) {
            if (free_on_error) {
                /*
                 * Slot resources already freed and NULLed by parse_entry.
                 * Do NOT increment result->count — reuse this slot for the
                 * next entry by leaving result->count unchanged.
                 */
                fprintf(stderr,
                    "[warn] Entry %u failed; slot recycled (--free-on-error).\n", i);
                continue;
            } else {
                fprintf(stderr, "[error] Entry %u failed; aborting parse.\n", i);
                return -1;
            }
        }

        result->count++;
    }

    return 0;
}

/* ══════════════════════════════════════════════════════════════════════════
 * build_report
 * ══════════════════════════════════════════════════════════════════════════ */

void build_report(const ParseResult *result, char *buf, size_t bufsz)
{
    if (bufsz == 0) return;

    /* Start with an empty, NUL-terminated buffer */
    buf[0] = '\0';
    size_t used = 0;

    /* Header line */
    int n = snprintf(buf, bufsz,
        "=== Metadata Report (v%u, %d entries) ===\n",
        result->header.version, result->count);
    if (n < 0 || (size_t)n >= bufsz) {
        buf[bufsz - 1] = '\0';
        return;
    }
    used = (size_t)n;

    for (int i = 0; i < result->count; i++) {
        const MetaEntry *e = &result->entries[i];

        if (used >= bufsz - 1) break;   /* no space left */

        /*
         * T8 (CWE-787) — snprintf with remaining-space tracking.
         * bufsz - used is always >= 1 here (checked above).
         *
         * T9 (CWE-134) — e->value is passed as a positional ARGUMENT (%s),
         * never as the format string.  Format string injection is impossible.
         */
        n = snprintf(buf + used, bufsz - used,
            "  [%2d] tag=0x%02X  len=%-3u  value=\"%s\"\n",
            i, e->tag_id, e->length, e->value);

        if (n < 0) break;
        used += (size_t)n;
        if (used >= bufsz) {
            /* snprintf truncated — ensure NUL and stop */
            buf[bufsz - 1] = '\0';
            break;
        }
    }
}

/* ══════════════════════════════════════════════════════════════════════════
 * free_result
 * ══════════════════════════════════════════════════════════════════════════ */

void free_result(ParseResult *result)
{
    /*
     * T4 (CWE-416) — iterate ALL slots up to MAX_TAGS (not just count),
     * because a failed entry with free_on_error=0 may have allocated extra
     * before the parse loop was aborted.
     *
     * After free(), set to NULL so double-free is impossible even if
     * free_result() is called twice by accident.
     */
    for (int i = 0; i < MAX_TAGS; i++) {
        if (result->entries[i].extra != NULL) {
            free(result->entries[i].extra);
            result->entries[i].extra = NULL;
        }
    }
}
