#!/usr/bin/env python3
"""
test.py — generate test .imgf fixtures and run the parser against them.

Usage:
    python test.py [--run]   # --run also executes the binary and checks output
"""

import struct
import os
import subprocess
import sys

MAGIC = b'IMGF'
BINARY = './img_meta_parser'


def write_imgf(path: str, version: int, entries: list[tuple[int, bytes]]) -> None:
    """Write a well-formed .imgf file."""
    with open(path, 'wb') as f:
        tag_count = len(entries)
        # Header: magic(4) + version(2 LE) + tag_count(2 LE)
        f.write(MAGIC)
        f.write(struct.pack('<H', version))
        f.write(struct.pack('<H', tag_count))
        for tag_id, payload in entries:
            length = len(payload)
            f.write(struct.pack('BB', tag_id, length))
            f.write(payload)


def make_fixtures():
    fixtures = {}

    # ── 1. valid.imgf — normal file with 3 entries ──────────────────────
    path = 'valid.imgf'
    write_imgf(path, version=1, entries=[
        (0x01, b'Hello, World!'),
        (0x02, b'2024-01-01'),
        (0x10, b'Canon EOS R5'),
    ])
    fixtures[path] = {'args': [], 'expect_ok': True}

    # ── 2. max_entries.imgf — exactly 32 entries ─────────────────────────
    path = 'max_entries.imgf'
    write_imgf(path, version=2, entries=[
        (i, f'value_{i:02d}'.encode()) for i in range(32)
    ])
    fixtures[path] = {'args': [], 'expect_ok': True}

    # ── 3. overflow_tag_count.imgf — tag_count = 200 (> MAX_TAGS=32) ────
    # Parser should clamp to 32 and read only 32 entries from file.
    path = 'overflow_tag_count.imgf'
    with open(path, 'wb') as f:
        f.write(MAGIC)
        f.write(struct.pack('<H', 1))
        f.write(struct.pack('<H', 200))   # crafted: 200 > MAX_TAGS
        for i in range(32):               # only write 32 real entries
            f.write(struct.pack('BB', i, 4))
            f.write(b'AAAA')
    fixtures[path] = {'args': [], 'expect_ok': True}

    # ── 4. long_value.imgf — entry with length=255 (> VALUE_BUF-1=63) ───
    # Parser should copy 63 bytes and discard the rest.
    path = 'long_value.imgf'
    payload = b'X' * 255
    write_imgf(path, version=1, entries=[
        (0x01, payload),
        (0x02, b'short'),
    ])
    fixtures[path] = {'args': [], 'expect_ok': True}

    # ── 5. truncated.imgf — file cut off mid-entry ───────────────────────
    path = 'truncated.imgf'
    with open(path, 'wb') as f:
        f.write(MAGIC)
        f.write(struct.pack('<H', 1))
        f.write(struct.pack('<H', 3))
        f.write(struct.pack('BB', 0x01, 10))
        f.write(b'complete!!')   # 10 bytes — OK
        f.write(struct.pack('BB', 0x02, 20))
        f.write(b'truncated')    # only 9 bytes — file ends here
    fixtures[path] = {'args': ['--free-on-error'], 'expect_ok': True}

    # ── 6. bad_magic.imgf — wrong magic bytes ────────────────────────────
    path = 'bad_magic.imgf'
    with open(path, 'wb') as f:
        f.write(b'JUNK')
        f.write(struct.pack('<H', 1))
        f.write(struct.pack('<H', 1))
        f.write(struct.pack('BB', 0x01, 3))
        f.write(b'abc')
    fixtures[path] = {'args': [], 'expect_ok': False}

    # ── 7. empty.imgf — file with 0 entries ─────────────────────────────
    path = 'empty.imgf'
    write_imgf(path, version=1, entries=[])
    fixtures[path] = {'args': [], 'expect_ok': True}

    # ── 8. short_header.imgf — file is only 4 bytes ─────────────────────
    path = 'short_header.imgf'
    with open(path, 'wb') as f:
        f.write(MAGIC)          # only 4 bytes — header needs 8
    fixtures[path] = {'args': [], 'expect_ok': False}

    # ── 9. null_value.imgf — entry with length=0 ────────────────────────
    path = 'null_value.imgf'
    write_imgf(path, version=1, entries=[
        (0x05, b''),            # zero-length payload
        (0x06, b'normal'),
    ])
    fixtures[path] = {'args': [], 'expect_ok': True}

    # ── 10. free_on_error.imgf — mix of good and broken entries ──────────
    path = 'free_on_error.imgf'
    with open(path, 'wb') as f:
        f.write(MAGIC)
        f.write(struct.pack('<H', 1))
        f.write(struct.pack('<H', 4))
        # entry 0: good
        f.write(struct.pack('BB', 0x01, 5))
        f.write(b'hello')
        # entry 1: good
        f.write(struct.pack('BB', 0x02, 3))
        f.write(b'bye')
        # entry 2: claims 10 bytes but file ends — triggers parse_entry error
        f.write(struct.pack('BB', 0x03, 10))
        f.write(b'short')      # only 5 bytes
    fixtures[path] = {'args': ['--free-on-error'], 'expect_ok': True}

    return fixtures


def run_tests(fixtures: dict):
    print(f"{'Fixture':<30}  {'Args':<20}  {'Result'}")
    print('-' * 70)
    passed = failed = 0

    for path, meta in sorted(fixtures.items()):
        args = [BINARY] + meta['args'] + [path]
        try:
            proc = subprocess.run(
                args,
                capture_output=True,
                text=True,
                timeout=5,
            )
            ok = (proc.returncode == 0) == meta['expect_ok']
            status = 'PASS' if ok else 'FAIL'
            if ok:
                passed += 1
            else:
                failed += 1
            print(f"{path:<30}  {' '.join(meta['args']):<20}  {status}")
            if not ok:
                print(f"  stdout: {proc.stdout[:120]}")
                print(f"  stderr: {proc.stderr[:120]}")
        except FileNotFoundError:
            print(f"{path:<30}  {' '.join(meta['args']):<20}  SKIP (binary not found)")
        except subprocess.TimeoutExpired:
            print(f"{path:<30}  {' '.join(meta['args']):<20}  FAIL (timeout)")
            failed += 1

    print('-' * 70)
    print(f"Results: {passed} passed, {failed} failed")
    return failed == 0


if __name__ == '__main__':
    run_flag = '--run' in sys.argv

    print("Generating test fixtures...")
    fixtures = make_fixtures()
    print(f"Generated {len(fixtures)} fixture files.\n")

    if run_flag:
        if not os.path.exists(BINARY):
            print(f"[warn] Binary '{BINARY}' not found. Run 'make' first.")
            sys.exit(1)
        success = run_tests(fixtures)
        sys.exit(0 if success else 1)
    else:
        for path in sorted(fixtures):
            print(f"  {path}")
        print("\nRun 'make && python test.py --run' to execute tests.")
