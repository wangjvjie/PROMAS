# Image Metadata Parser

A C99 command-line tool that parses a custom binary image metadata format
(EXIF-like) and prints all tag/value pairs plus a summary report.

## Build

```bash
# Release build (optimised, fortified)
make

# Debug build (AddressSanitizer + UBSan — recommended for testing)
make debug
```

Requires GCC or Clang with C99 support.

## Usage

```bash
./img_meta_parser <file.imgf>
./img_meta_parser --free-on-error <file.imgf>
```

**`--free-on-error`** — if a tag entry fails to parse (truncated file, I/O error),
free its resources, recycle the slot, and continue parsing the next entry instead
of aborting.

## Binary Format Specification

```
Offset  Size  Field
──────────────────────────────────────────────────────
0       4     Magic number  "IMGF" (0x49 0x4D 0x47 0x46)
4       2     Version       uint16, little-endian
6       2     Tag count     uint16, little-endian (clamped to 32)
8+      ...   Tag entries

Tag entry:
  0     1     Tag ID    uint8
  1     1     Length    uint8  (0–255; bytes of payload)
  2     N     Value     N raw bytes
```

### Constraints enforced by the parser

| Field       | Limit           | What happens if exceeded              |
|-------------|-----------------|---------------------------------------|
| tag_count   | MAX_TAGS = 32   | Clamped; excess entries skipped       |
| value bytes | VALUE_BUF-1 = 63| Truncated; file pointer advanced past |
| report buf  | REPORT_BUF = 512| Truncated gracefully via snprintf     |

## Generate Test Fixtures

```bash
# Generate fixture files
python test.py

# Build then run all tests
make debug && python test.py --run
```

Fixtures generated:

| File                    | Description                                    |
|-------------------------|------------------------------------------------|
| `valid.imgf`            | Normal 3-entry file                            |
| `max_entries.imgf`      | Exactly 32 entries                             |
| `overflow_tag_count.imgf`| tag_count=200 — clamped to 32               |
| `long_value.imgf`       | Entry with length=255 — truncated to 63 bytes  |
| `truncated.imgf`        | File cut off mid-entry                         |
| `bad_magic.imgf`        | Wrong magic bytes — rejected                   |
| `empty.imgf`            | 0 entries                                      |
| `short_header.imgf`     | Header < 8 bytes — rejected                    |
| `null_value.imgf`       | Entry with length=0                            |
| `free_on_error.imgf`    | Mix of good and broken entries                 |

## File Structure

```
img_meta_parser/
├── parser.h          Structs, constants, function prototypes
├── parser.c          Format parser (CWE-787, CWE-125, CWE-416 mitigations)
├── main.c            CLI entry point
├── Makefile          Release + debug build rules
├── test.py           Fixture generator + test runner
├── prd.md            Product requirements
├── architecture.json Architecture design
└── threat_model.md   Threat model (CWE-787, CWE-125, CWE-416, CWE-134)
```

## Security Mitigations

| CWE | Threat | Mitigation |
|-----|--------|------------|
| CWE-787 | Overflow via `length` field (max 255 into 64-byte buffer) | `copy_len = min(length, VALUE_BUF-1)`; NUL at `value[copy_len]` |
| CWE-787 | `tag_count` > 32 overflows `entries[]` array | Clamped to MAX_TAGS before loop |
| CWE-787 | `sprintf` overflow in report buffer | `snprintf` with remaining-space tracking |
| CWE-125 | Short file read → stale stack bytes as tag_count | `fread` return value checked == HEADER_SIZE |
| CWE-125 | Missing NUL → `printf` reads past buffer | `memset(entry, 0)` before every read |
| CWE-416 | Use-after-free on `entry->extra` slot reuse | `free(p); p = NULL;` — always in same block |
| CWE-134 | Format string via `value` field | `value` always passed as `%s` argument, never as format |
| CWE-476 | NULL deref on missing `argv[1]` | `argc >= 2` checked before any `argv` access |
