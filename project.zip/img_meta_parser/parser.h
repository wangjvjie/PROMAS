#ifndef PARSER_H
#define PARSER_H

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* ── Constants ─────────────────────────────────────────────────────────── */

#define MAGIC_0     'I'
#define MAGIC_1     'M'
#define MAGIC_2     'G'
#define MAGIC_3     'F'

#define MAX_TAGS    32          /* maximum tag entries per file              */
#define VALUE_BUF   64          /* bytes reserved per tag value (incl. NUL) */
#define REPORT_BUF  512         /* bytes for the summary report buffer       */
#define HEADER_SIZE 8           /* 4 magic + 2 version + 2 tag_count        */

/* ── Structs ────────────────────────────────────────────────────────────── */

/*
 * One parsed metadata tag entry.
 *
 * value[]  holds the payload, always NUL-terminated, capped to VALUE_BUF-1
 *          bytes of content.
 *
 * extra    optional heap-allocated annotation string; may be NULL.
 *          MUST be freed via free_result() — never freed inline except in
 *          the --free-on-error recovery path, where it is set to NULL
 *          immediately after free().
 */
typedef struct {
    uint8_t  tag_id;
    uint8_t  length;            /* original length from file                */
    char     value[VALUE_BUF];  /* payload — always NUL-terminated          */
    char    *extra;             /* nullable heap annotation                  */
} MetaEntry;

/*
 * Parsed file header.
 */
typedef struct {
    uint8_t  magic[4];
    uint16_t version;
    uint16_t tag_count;         /* clamped to MAX_TAGS during parse_header  */
} ImageHeader;

/*
 * Aggregated parse result handed back to the caller.
 */
typedef struct {
    ImageHeader header;
    MetaEntry   entries[MAX_TAGS];
    int         count;          /* number of successfully parsed entries    */
} ParseResult;

/* ── Function prototypes ────────────────────────────────────────────────── */

/*
 * parse_header — read and validate the 8-byte file header.
 * Returns 0 on success, -1 on I/O error or magic mismatch.
 */
int parse_header(FILE *fp, ImageHeader *hdr);

/*
 * parse_entry — read one tag entry from fp into entry.
 * If free_on_error is non-zero and a recoverable error occurs, frees
 * entry->extra, sets entry->extra = NULL, and returns -1 so the caller
 * can reuse the slot.
 * Returns 0 on success, -1 on error.
 */
int parse_entry(FILE *fp, MetaEntry *entry, int free_on_error);

/*
 * parse_image — parse header + all tag entries from fp.
 * Skips failed entries when free_on_error is set.
 * Returns 0 on success, -1 on fatal (header-level) error.
 */
int parse_image(FILE *fp, ParseResult *result, int free_on_error);

/*
 * build_report — format all entries into buf[bufsz].
 * Always NUL-terminates buf. Truncates gracefully if full.
 */
void build_report(const ParseResult *result, char *buf, size_t bufsz);

/*
 * free_result — free all entry->extra pointers; sets each to NULL.
 */
void free_result(ParseResult *result);

/* ── Utility macros ─────────────────────────────────────────────────────── */

#define MIN(a, b)  ((a) < (b) ? (a) : (b))

#endif /* PARSER_H */
