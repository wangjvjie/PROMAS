/*
 * main.c — CLI entry point for img_meta_parser.
 *
 * Usage:
 *   ./img_meta_parser [--free-on-error] <file.imgf>
 */

#include "parser.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void print_usage(const char *prog)
{
    fprintf(stderr, "Usage: %s [--free-on-error] <file.imgf>\n", prog);
    fprintf(stderr, "  --free-on-error  Skip failed entries instead of aborting\n");
}

int main(int argc, char **argv)
{
    int         free_on_error = 0;
    const char *filepath      = NULL;

    /*
     * T10 (CWE-476) / T11 (CWE-125) — bounds-checked argv iteration.
     * We only access argv[i] for i in [1, argc).
     */
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--free-on-error") == 0) {
            free_on_error = 1;
        } else if (argv[i][0] != '-') {
            filepath = argv[i];
        } else {
            fprintf(stderr, "[error] Unknown option: %s\n", argv[i]);
            print_usage(argv[0]);
            return EXIT_FAILURE;
        }
    }

    /* T10 — require at least a filename */
    if (filepath == NULL) {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    FILE *fp = fopen(filepath, "rb");
    if (fp == NULL) {
        fprintf(stderr, "[error] Cannot open '%s'.\n", filepath);
        return EXIT_FAILURE;
    }

    ParseResult result;
    /* parse_image zeroes result internally; this is belt-and-braces */
    memset(&result, 0, sizeof(result));

    int rc = parse_image(fp, &result, free_on_error);
    fclose(fp);   /* close before any further processing — file no longer needed */
    fp = NULL;

    if (rc != 0) {
        fprintf(stderr, "[error] Parsing failed.\n");
        free_result(&result);
        return EXIT_FAILURE;
    }

    /* ── Print individual tag entries ─────────────────────────────────── */

    printf("File   : %s\n", filepath);
    printf("Version: %u\n", result.header.version);
    printf("Entries: %d\n\n", result.count);

    for (int i = 0; i < result.count; i++) {
        const MetaEntry *e = &result.entries[i];
        /*
         * Print tag_id as hex and value as a string.
         * value[] is always NUL-terminated (guaranteed by parse_entry).
         * extra may be NULL if malloc failed on that entry.
         */
        printf("Tag 0x%02X  len=%-3u  value=\"%s\"",
               e->tag_id, e->length, e->value);
        if (e->extra != NULL) {
            printf("  [%s]", e->extra);
        }
        printf("\n");
    }

    /* ── Build and print the summary report ───────────────────────────── */

    char report[REPORT_BUF];
    memset(report, 0, sizeof(report));
    build_report(&result, report, sizeof(report));

    printf("\n%s\n", report);

    /* ── Cleanup ───────────────────────────────────────────────────────── */

    free_result(&result);

    return EXIT_SUCCESS;
}
