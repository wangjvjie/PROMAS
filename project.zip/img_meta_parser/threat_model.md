# Threat Model — Image Metadata Parser (C)

## 1. Global Security Context

**Trust Boundaries**
- Input file (binary) — fully untrusted; all bytes are attacker-controlled
- `argc` / `argv` — untrusted; filename and flags from the user
- File system — read-only from the parser's perspective
- `stdout` — trusted output sink

**Key Assets**
- Process memory (stack and heap) — corruption enables RCE or info-leak
- Program control flow — overwritten return addresses / function pointers
- Heap allocator metadata — corruption via overflow can compromise the allocator

**Attacker Model**
- Attacker supplies a crafted `.imgf` file; the binary parses it without
  prior authentication
- Goals: crash the parser (DoS), leak memory (info-leak), or achieve
  arbitrary code execution via memory corruption

---

## 2. Function-Level Threats

### Function: `parser.c:parse_entry()`
*Role*: Reads one tag entry — 1-byte tag ID, 1-byte length, then `length` payload bytes  
*Untrusted inputs*: `tag_id`, `length`, payload bytes — all from the file  
*Security-relevant operations*: `fread` into `entry->value[VALUE_BUF]`, `memcpy`, pointer write  

*Threats*:

- **T1: Stack/heap buffer overflow via `length` field (CWE-787)**  
  The `length` field is a `uint8_t` (0–255). `VALUE_BUF` is 64 bytes.  
  If the code copies `length` bytes without capping:  
  ```c
  fread(entry->value, 1, entry->length, fp);   // ← writes up to 255 bytes into a 64-byte buffer
  ```  
  An attacker sets `length=255` and provides 255 payload bytes → 191-byte overflow past the buffer end, corrupting adjacent struct fields or the return address (stack) / heap metadata.

- **T2: Off-by-one on NUL termination (CWE-787)**  
  Writing exactly `VALUE_BUF` bytes then appending `'\0'` at index `VALUE_BUF` writes one byte past the buffer:  
  ```c
  fread(entry->value, 1, VALUE_BUF, fp);
  entry->value[VALUE_BUF] = '\0';    // ← one byte past end
  ```

- **T3: Out-of-bounds read via missing NUL terminator (CWE-125)**  
  If the payload contains no `'\0'` and `length < VALUE_BUF`, and the buffer is not initialised, `printf("%s", entry->value)` reads past the payload into unintialised memory until a zero byte is found — leaking stack/heap data.

- **T4: Use-after-free on `entry->extra` (CWE-416)**  
  With `--free-on-error`, if a previous iteration freed `entry->extra` and set it to some non-NULL sentinel (or forgot to NULL it), the next iteration may call `free()` on it again (double-free) or dereference it:  
  ```c
  free(entry->extra);
  // missing: entry->extra = NULL;
  // next loop iteration reuses same slot:
  if (entry->extra) free(entry->extra);  // ← double-free
  ```

*Protections*:
- Cap copy length: `size_t copy_len = (entry->length < VALUE_BUF) ? entry->length : VALUE_BUF - 1`
- NUL-terminate at `entry->value[copy_len]` — always within bounds
- Memset `entry->value` to zero before any read (guarantees termination even on partial read)
- Seek past `length - copy_len` remaining bytes so the file pointer stays in sync
- After `free(entry->extra)`, immediately write `entry->extra = NULL`

---

### Function: `parser.c:parse_header()`
*Role*: Reads the 8-byte file header and validates the magic number  
*Untrusted inputs*: All 8 bytes from the file  
*Security-relevant operations*: `fread` of fixed size, endian conversion, value interpretation  

*Threats*:

- **T5: Out-of-bounds read on short file (CWE-125)**  
  If the file is < 8 bytes, `fread` returns fewer bytes than requested. Reading
  `hdr->tag_count` from a partially-filled struct reads uninitialised stack bytes —
  and a stale tag_count of e.g. 0xFFFF causes the entry loop to run 32 iterations
  even on an empty file, triggering repeated `fread` calls that immediately return 0
  but may also read past the file buffer in non-standard `FILE` implementations.

- **T6: Integer wraparound on `tag_count` (CWE-125 / CWE-787)**  
  `tag_count` is a `uint16_t` (0–65535). If passed directly as the loop bound:  
  ```c
  for (int i = 0; i < hdr->tag_count; i++)
  ```  
  …and the array is only `MetaEntry entries[MAX_TAGS]` (32 elements), a crafted
  `tag_count = 200` causes out-of-bounds writes to `entries[32]`..`entries[199]` —
  corrupting the stack frame or heap.

- **T7: Magic number bypass — no full comparison (CWE-20)**  
  Comparing only the first 2 of 4 magic bytes lets crafted files with a
  partially-matching header pass validation and reach the parsing logic.

*Protections*:
- Check `fread` return value == expected byte count; return error on short read
- `hdr->tag_count = MIN(hdr->tag_count, MAX_TAGS)` — clamp before any loop
- Compare all 4 magic bytes: `memcmp(hdr->magic, EXPECTED_MAGIC, 4) == 0`

---

### Function: `parser.c:build_report()`
*Role*: Formats all parsed entries into a fixed 512-byte `report` buffer  
*Untrusted inputs*: `entry->value` strings (originate from file payload)  
*Security-relevant operations*: String formatting into fixed buffer  

*Threats*:

- **T8: Buffer overflow via `sprintf` (CWE-787)**  
  Using `sprintf(buf, "Tag %d: %s\n", id, value)` without tracking remaining space.
  With 32 entries each contributing up to ~75 chars, total output can reach ~2400 bytes —
  far exceeding the 512-byte `report` buffer, corrupting adjacent stack variables.

- **T9: Format string injection via `value` field (CWE-134)**  
  If `value` is passed as the format string: `sprintf(buf, entry->value)` — an attacker
  embeds `%n`, `%s`, `%x` in the payload to read/write arbitrary memory.

*Protections*:
- Use `snprintf` with remaining-space tracking:  
  ```c
  size_t used = strlen(buf);
  snprintf(buf + used, bufsz - used, "Tag %u: %s\n", entry->tag_id, entry->value);
  ```
- Always pass `entry->value` as a positional argument to `snprintf`, never as the format string
- Truncate gracefully when buffer is full — do not abort or overflow

---

### Function: `main.c:main()`
*Role*: CLI argument parsing, file open, orchestration  
*Untrusted inputs*: `argv[1]` (filename), `argv` flags  

*Threats*:

- **T10: NULL dereference on missing filename (CWE-476)**  
  `fopen(argv[1], "rb")` without checking `argc >= 2` — if called with no arguments,
  `argv[1]` is NULL and `fopen` dereferences it → segfault.

- **T11: Out-of-bounds read on `argv` (CWE-125)**  
  Iterating `argv` past `argc` to find `--free-on-error` without bounds checking.

*Protections*:
- Check `argc >= 2` before accessing `argv[1]`; print usage and return `EXIT_FAILURE`
- Only iterate `argv[i]` for `i < argc`

---

## 3. Project Integrity

**Critical Risks**

1. **`sprintf` → `snprintf`**: The spec says "512-byte output buffer using sprintf" —
   this is the most obvious vulnerability. The implementation uses `snprintf` with
   remaining-space tracking throughout. The buffer is always NUL-terminated.

2. **Pointer slot reuse without NULL guard**: The `--free-on-error` path is the
   use-after-free trigger. Every `free()` call is followed by `ptr = NULL` in the
   same statement's scope before the pointer is next accessible.

3. **Uninitialised struct memory**: `MetaEntry entries[MAX_TAGS]` on the stack is
   zeroed with `memset` before the parse loop — preventing stale pointer reads if
   `free_on_error` is used on entry 0 and never-written entries are later iterated.

**Top 3 Attack Vectors**
1. `length=0xFF` in a tag entry → 191-byte overflow past `value[64]` → stack smash (T1)
2. `tag_count=0xFFFF` in header → out-of-bounds write past `entries[32]` → stack smash (T6)
3. `--free-on-error` + crafted file that forces a parse error on every entry →
   `entry->extra` freed and re-freed on next slot reuse (T4)

**Recommended Additions**
- Compile with `-D_FORTIFY_SOURCE=2` to harden `memcpy`/`sprintf` at libc level
- Enable `-fstack-protector-strong` to detect stack canary overwrite
- Run `valgrind --leak-check=full` and `AddressSanitizer` on all test fixtures
- Fuzz with `AFL++` or `libFuzzer` targeting `parse_image()`
