"""
app.py — Flask entry point for ML Model Inference API.
"""
import functools
import hmac
import os
import tempfile
from pathlib import Path

from flask import Flask, jsonify, request, render_template, abort
from werkzeug.exceptions import RequestEntityTooLarge

from model_manager import ModelManager, ModelState

# ---------------------------------------------------------------------------
# Config from environment
# ---------------------------------------------------------------------------

API_KEY          = os.environ.get('API_KEY', '')
MAX_UPLOAD_BYTES = int(os.environ.get('MAX_UPLOAD_BYTES', 20 * 1024 ** 3))  # 20 GB
MAX_NEW_TOKENS   = int(os.environ.get('MAX_NEW_TOKENS', 512))
MAX_PROMPT_CHARS = int(os.environ.get('MAX_PROMPT_CHARS', 8000))
INFERENCE_TIMEOUT= float(os.environ.get('INFERENCE_TIMEOUT_S', 120.0))
MODEL_DIR        = os.environ.get('MODEL_DIR', './models')
GPU_MEM_UTIL     = float(os.environ.get('GPU_MEMORY_UTILIZATION', '0.85'))

if not API_KEY:
    import secrets
    API_KEY = secrets.token_hex(32)
    print(f"[WARN] API_KEY not set. Generated temporary key: {API_KEY}")
    print("[WARN] Set API_KEY environment variable for production use.")

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = MAX_UPLOAD_BYTES

manager = ModelManager(
    model_dir=MODEL_DIR,
    max_new_tokens=MAX_NEW_TOKENS,
    inference_timeout=INFERENCE_TIMEOUT,
    gpu_memory_utilization=GPU_MEM_UTIL,
)

# ---------------------------------------------------------------------------
# Auth decorator (T15, T17, T18, T19)
# ---------------------------------------------------------------------------

def require_api_key(f):
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get('Authorization', '')
        if not auth.startswith('Bearer '):
            return jsonify({'error': 'Missing Authorization header.'}), 401
        token = auth[len('Bearer '):]
        # Constant-time comparison to prevent timing attacks (T15)
        if not hmac.compare_digest(token, API_KEY):
            return jsonify({'error': 'Invalid API key.'}), 401
        return f(*args, **kwargs)
    return decorated


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------

@app.errorhandler(RequestEntityTooLarge)
def handle_too_large(e):
    return jsonify({'error': f'Upload too large. Limit: {MAX_UPLOAD_BYTES // 1024**3} GB.'}), 413


@app.errorhandler(404)
def handle_404(e):
    return jsonify({'error': 'Not found.'}), 404


@app.errorhandler(405)
def handle_405(e):
    return jsonify({'error': 'Method not allowed.'}), 405


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route('/')
def index():
    return render_template(
        'index.html',
        max_upload_gb=MAX_UPLOAD_BYTES // 1024 ** 3,
        max_new_tokens=MAX_NEW_TOKENS,
        max_prompt_chars=MAX_PROMPT_CHARS,
    )


@app.route('/upload', methods=['POST'])
@require_api_key
def upload():
    """
    POST /upload  multipart/form-data  field: model  (a .zip file)

    Streams the upload to a temp file, then hands it to model_manager
    for async validation + extraction + vLLM load.
    """
    if 'model' not in request.files:
        return jsonify({'error': "Missing 'model' file field."}), 400

    file = request.files['model']
    if not file.filename:
        return jsonify({'error': 'No filename provided.'}), 400

    # Extension check — original filename is used ONLY for this check,
    # never for naming files on disk (T3)
    if not file.filename.lower().endswith('.zip'):
        return jsonify({'error': 'Only .zip archives are accepted.'}), 400

    # Stream to a temp file with a safe, UUID-based name (T3)
    tmp_fd, tmp_path = tempfile.mkstemp(suffix='.zip', dir='./uploads')
    try:
        bytes_received = 0
        with os.fdopen(tmp_fd, 'wb') as tmp_file:
            chunk_size = 1024 * 1024  # 1 MB
            while True:
                chunk = file.stream.read(chunk_size)
                if not chunk:
                    break
                bytes_received += len(chunk)
                # Belt-and-braces size check (T4 — chunked encoding bypass)
                if bytes_received > MAX_UPLOAD_BYTES:
                    os.remove(tmp_path)
                    return jsonify({'error': 'Upload too large.'}), 413
                tmp_file.write(chunk)
    except Exception as exc:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        return jsonify({'error': f'Upload failed: {exc}'}), 500

    accepted, result = manager.load_model_async(tmp_path)
    if not accepted:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        return jsonify({'error': result}), 409

    return jsonify({
        'message': 'Upload accepted. Model is being validated and loaded.',
        'model_id': result,
    }), 202


@app.route('/status', methods=['GET'])
@require_api_key
def status():
    """GET /status — returns current model state."""
    return jsonify(manager.get_status()), 200


@app.route('/infer', methods=['POST'])
@require_api_key
def infer():
    """
    POST /infer  application/json
    {
        "prompt":      "string (required)",
        "max_tokens":  256,        (optional, server-capped)
        "temperature": 0.7,        (optional)
        "top_p":       0.95        (optional)
    }
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({'error': 'Request body must be JSON.'}), 400

    prompt = data.get('prompt', '')
    if not isinstance(prompt, str) or not prompt.strip():
        return jsonify({'error': "'prompt' must be a non-empty string."}), 400

    # Hard prompt length cap (T13)
    if len(prompt) > MAX_PROMPT_CHARS:
        return jsonify({'error': f"Prompt too long. Max {MAX_PROMPT_CHARS} characters."}), 400

    try:
        max_tokens  = int(data.get('max_tokens', 256))
        temperature = float(data.get('temperature', 0.7))
        top_p       = float(data.get('top_p', 0.95))
    except (TypeError, ValueError):
        return jsonify({'error': 'Invalid parameter type.'}), 400

    try:
        text = manager.generate(
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
        )
    except RuntimeError as exc:
        return jsonify({'error': str(exc)}), 503

    return jsonify({'generated_text': text}), 200


@app.route('/model', methods=['DELETE'])
@require_api_key
def delete_model():
    """DELETE /model — unload the current model and free resources."""
    manager.unload()
    return jsonify({'message': 'Model unloaded and resources freed.'}), 200


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    Path('./uploads').mkdir(exist_ok=True)
    Path(MODEL_DIR).mkdir(parents=True, exist_ok=True)
    # debug=False in production — never echo exceptions to client (T18)
    app.run(host='0.0.0.0', port=5000, debug=False)
