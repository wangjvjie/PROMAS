"""
model_manager.py — Thread-safe model state machine, zip validator, vLLM wrapper.
"""
import gc
import os
import shutil
import threading
import time
import uuid
import zipfile
import posixpath
from pathlib import Path
from typing import Tuple

# vLLM is imported lazily so the rest of the app still starts without a GPU
try:
    from vllm import LLM, SamplingParams
    VLLM_AVAILABLE = True
except ImportError:
    VLLM_AVAILABLE = False

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DANGEROUS_EXTENSIONS = {
    '.pkl', '.pickle', '.pt', '.pth',
    '.npy',         # numpy pickle
    '.npz',         # zipped numpy
    '.joblib',      # sklearn pickle
}

# HuggingFace / safetensors model files we allow
SAFE_EXTENSIONS = {
    '.safetensors', '.json', '.txt', '.model',
    '.tiktoken', '.py',   # tokenizer scripts — scanned but allowed
    '.md', '.bin',        # .bin allowed only if safetensors also present
}

MAX_EXTRACT_BYTES = int(os.environ.get('MAX_EXTRACT_BYTES', 50 * 1024 ** 3))  # 50 GB
KNOWN_ARCHITECTURES = {
    # Add more as needed — this is the trust gate for config.json
    'LlamaForCausalLM', 'MistralForCausalLM', 'Phi3ForCausalLM',
    'GPT2LMHeadModel', 'GPTNeoXForCausalLM', 'FalconForCausalLM',
    'GemmaForCausalLM', 'Gemma2ForCausalLM', 'Qwen2ForCausalLM',
    'DeepseekV2ForCausalLM', 'MixtralForCausalLM',
}


# ---------------------------------------------------------------------------
# State machine
# ---------------------------------------------------------------------------

class ModelState:
    IDLE       = 'idle'
    UPLOADING  = 'uploading'
    EXTRACTING = 'extracting'
    LOADING    = 'loading'
    READY      = 'ready'
    ERROR      = 'error'


class ModelManager:
    def __init__(
        self,
        model_dir: str,
        max_new_tokens: int = 512,
        inference_timeout: float = 120.0,
        gpu_memory_utilization: float = 0.85,
    ):
        self._model_dir = Path(model_dir)
        self._model_dir.mkdir(parents=True, exist_ok=True)
        self._max_new_tokens = max_new_tokens
        self._inference_timeout = inference_timeout
        self._gpu_memory_utilization = gpu_memory_utilization

        self._lock = threading.Lock()
        self._state = ModelState.IDLE
        self._model_id = None
        self._error = None
        self._llm = None
        self._current_model_path = None

    # ------------------------------------------------------------------
    # Public status
    # ------------------------------------------------------------------

    def get_status(self) -> dict:
        with self._lock:
            return {
                'state':    self._state,
                'model_id': self._model_id,
                'error':    self._error,
            }

    # ------------------------------------------------------------------
    # Upload entry point
    # ------------------------------------------------------------------

    def load_model_async(self, zip_path: str) -> Tuple[bool, str]:
        """
        Called from the upload route. Rejects if a model is already
        loading or loaded. Returns (accepted, reason).
        """
        with self._lock:
            if self._state not in (ModelState.IDLE, ModelState.ERROR):
                return False, f"Cannot upload while state is '{self._state}'. Delete current model first."
            self._state = ModelState.UPLOADING
            self._error = None
            model_id = str(uuid.uuid4())
            self._model_id = model_id

        t = threading.Thread(
            target=self._pipeline,
            args=(zip_path, model_id),
            daemon=True,
        )
        t.start()
        return True, model_id

    # ------------------------------------------------------------------
    # Internal pipeline (runs in background thread)
    # ------------------------------------------------------------------

    def _pipeline(self, zip_path: str, model_id: str):
        target_dir = self._model_dir / model_id
        try:
            # 1. Validate
            self._set_state(ModelState.EXTRACTING)
            ok, reason = self.validate_zip(zip_path, target_dir)
            if not ok:
                raise ValueError(f"Zip validation failed: {reason}")

            # 2. Extract
            model_path = self.safe_extract(zip_path, target_dir)

            # 3. Load via vLLM
            self._set_state(ModelState.LOADING)
            self._load_vllm(model_path)

            with self._lock:
                self._current_model_path = str(target_dir)
                self._state = ModelState.READY

        except Exception as exc:
            with self._lock:
                self._state = ModelState.ERROR
                self._error = str(exc)
            # Clean up partial extraction
            if target_dir.exists():
                shutil.rmtree(target_dir, ignore_errors=True)
        finally:
            # Always remove the uploaded zip
            try:
                os.remove(zip_path)
            except OSError:
                pass

    def _set_state(self, state: str):
        with self._lock:
            self._state = state

    # ------------------------------------------------------------------
    # Zip validation (T1, T5, T6, T7)
    # ------------------------------------------------------------------

    def validate_zip(self, zip_path: str, target_dir: Path) -> Tuple[bool, str]:
        """
        Opens zip once, checks every entry for:
          - path traversal (zip-slip)
          - symlinks
          - dangerous file extensions
          - decompression bomb (cumulative size)
        Also requires at least one .safetensors file.
        """
        target_str = str(target_dir.resolve()) + os.sep
        total_size = 0
        has_safetensors = False

        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                for info in zf.infolist():
                    # --- Symlink check (T6) ---
                    # Unix symlink: external attributes encode file mode
                    unix_attrs = (info.external_attr >> 16) & 0xFFFF
                    if unix_attrs and (unix_attrs & 0xA000) == 0xA000:
                        return False, f"Symlink entry rejected: {info.filename}"

                    # --- Path normalisation + traversal check (T1, T7) ---
                    # Normalise using posixpath to catch both / and Windows \ traversal
                    name = posixpath.normpath(info.filename.replace('\\', '/'))
                    if name.startswith('..') or '/..' in name:
                        return False, f"Path traversal entry rejected: {info.filename}"

                    resolved = str((target_dir / name).resolve())
                    if not resolved.startswith(target_str):
                        return False, f"Path escape rejected: {info.filename}"

                    # --- Dangerous extension check (T5) ---
                    ext = Path(name).suffix.lower()
                    if ext in DANGEROUS_EXTENSIONS:
                        return False, (
                            f"Dangerous file type '{ext}' rejected: {info.filename}. "
                            "Use safetensors format instead of pickle/PyTorch binaries."
                        )

                    # --- Decompression bomb check (T2) ---
                    total_size += info.file_size
                    if total_size > MAX_EXTRACT_BYTES:
                        return False, (
                            f"Uncompressed size exceeds limit "
                            f"({MAX_EXTRACT_BYTES // 1024**3} GB)."
                        )

                    if ext == '.safetensors':
                        has_safetensors = True

            if not has_safetensors:
                return False, (
                    "No .safetensors file found. "
                    "Only HuggingFace safetensors format is supported."
                )

        except zipfile.BadZipFile as exc:
            return False, f"Invalid zip file: {exc}"

        return True, "ok"

    # ------------------------------------------------------------------
    # Safe extraction (T1, T8, T9)
    # ------------------------------------------------------------------

    def safe_extract(self, zip_path: str, target_dir: Path) -> str:
        """
        Extracts entries one-by-one using a single open ZipFile handle
        (eliminates TOCTOU gap between validate and extract).
        Returns the extracted model directory path.
        """
        target_dir.mkdir(parents=True, exist_ok=True)
        target_str = str(target_dir.resolve()) + os.sep
        bytes_written = 0

        with zipfile.ZipFile(zip_path, 'r') as zf:
            for info in zf.infolist():
                # Skip symlinks
                unix_attrs = (info.external_attr >> 16) & 0xFFFF
                if unix_attrs and (unix_attrs & 0xA000) == 0xA000:
                    continue

                name = posixpath.normpath(info.filename.replace('\\', '/'))
                out_path = (target_dir / name).resolve()
                out_str = str(out_path)

                # Double-check path escape (belt + braces)
                if not out_str.startswith(target_str):
                    raise ValueError(f"Path escape during extraction: {info.filename}")

                # Directory entry
                if info.filename.endswith('/'):
                    out_path.mkdir(parents=True, exist_ok=True)
                    continue

                out_path.parent.mkdir(parents=True, exist_ok=True)

                with zf.open(info) as src, open(out_path, 'wb') as dst:
                    chunk_size = 1024 * 1024  # 1 MB chunks
                    while True:
                        chunk = src.read(chunk_size)
                        if not chunk:
                            break
                        bytes_written += len(chunk)
                        if bytes_written > MAX_EXTRACT_BYTES:
                            raise ValueError("Decompression bomb: extraction size exceeded limit.")
                        dst.write(chunk)

        # Return the directory (could be a single nested subdir)
        return str(target_dir)

    # ------------------------------------------------------------------
    # vLLM load (T10, T11, T12)
    # ------------------------------------------------------------------

    def _load_vllm(self, model_path: str):
        if not VLLM_AVAILABLE:
            raise RuntimeError(
                "vLLM is not installed. Run: pip install vllm"
            )

        # Validate config.json architecture against allowlist (T10)
        config_path = Path(model_path) / 'config.json'
        if config_path.exists():
            import json
            try:
                with open(config_path) as f:
                    cfg = json.load(f)
                archs = cfg.get('architectures', [])
                for arch in archs:
                    if arch not in KNOWN_ARCHITECTURES:
                        raise ValueError(
                            f"Unknown model architecture '{arch}'. "
                            f"Allowed: {sorted(KNOWN_ARCHITECTURES)}"
                        )
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                raise ValueError(f"Invalid config.json: {exc}")

        self._llm = LLM(
            model=model_path,
            trust_remote_code=False,        # NEVER True — T12
            gpu_memory_utilization=self._gpu_memory_utilization,
            dtype='auto',
        )

    # ------------------------------------------------------------------
    # Inference (T13, T14, T16)
    # ------------------------------------------------------------------

    def generate(
        self,
        prompt: str,
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.95,
    ) -> str:
        with self._lock:
            if self._state != ModelState.READY:
                raise RuntimeError(
                    f"Model is not ready (state: {self._state}). "
                    "Wait for state=ready before sending inference requests."
                )
            llm = self._llm   # local ref inside lock — safe from concurrent unload

        # Server-side cap — client cannot exceed this (T14)
        capped_tokens = min(max_tokens, self._max_new_tokens)
        temperature = max(0.0, min(float(temperature), 2.0))
        top_p = max(0.01, min(float(top_p), 1.0))

        params = SamplingParams(
            max_tokens=capped_tokens,
            temperature=temperature,
            top_p=top_p,
        )
        outputs = llm.generate([prompt], params)
        return outputs[0].outputs[0].text

    # ------------------------------------------------------------------
    # Unload (T16)
    # ------------------------------------------------------------------

    def unload(self):
        with self._lock:
            llm = self._llm
            model_path = self._current_model_path
            self._llm = None
            self._current_model_path = None
            self._state = ModelState.IDLE
            self._model_id = None
            self._error = None

        if llm is not None:
            del llm
            gc.collect()
            try:
                import torch
                torch.cuda.empty_cache()
            except ImportError:
                pass

        if model_path and Path(model_path).exists():
            shutil.rmtree(model_path, ignore_errors=True)
