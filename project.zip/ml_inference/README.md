# ML Model Inference API

Upload a HuggingFace-compatible model zip and run text inference via vLLM.

## Requirements

- Python 3.10+
- NVIDIA GPU with CUDA (required by vLLM)
- CUDA toolkit ≥ 12.1

## Quick Start

```bash
cd ml_inference

# 1. Create virtual environment
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set API key
export API_KEY=$(python -c "import secrets; print(secrets.token_hex(32))")
echo "Your API key: $API_KEY"

# 4. Run
python app.py
```

Open http://localhost:5000 for the web UI.

## Model Format Requirements

The uploaded `model.zip` must contain a HuggingFace-compatible model:

| Required         | Description                        |
|------------------|------------------------------------|
| `*.safetensors`  | Model weights (safetensors format) |
| `config.json`    | Model architecture config          |
| `tokenizer*`     | Tokenizer files                    |

**Rejected files:** `.pkl`, `.pickle`, `.pt`, `.pth`, `.npy`, `.npz`, `.joblib`  
**Rejected architectures:** anything not in the `KNOWN_ARCHITECTURES` allowlist in `model_manager.py`

## API Reference

All endpoints require `Authorization: Bearer <API_KEY>` header.

### `POST /upload`
Upload a model zip for extraction and loading.

```bash
curl -X POST http://localhost:5000/upload \
  -H "Authorization: Bearer $API_KEY" \
  -F "model=@model.zip"
```

Response `202`:
```json
{"message": "Upload accepted...", "model_id": "uuid"}
```

### `GET /status`
Check current model state.

```bash
curl http://localhost:5000/status \
  -H "Authorization: Bearer $API_KEY"
```

Response:
```json
{"state": "ready", "model_id": "uuid", "error": null}
```

States: `idle` → `uploading` → `extracting` → `loading` → `ready` (or `error`)

### `POST /infer`
Run inference on the loaded model.

```bash
curl -X POST http://localhost:5000/infer \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Hello, world!", "max_tokens": 256, "temperature": 0.7}'
```

Response:
```json
{"generated_text": "..."}
```

Parameters:

| Field         | Type   | Default | Max (server) |
|---------------|--------|---------|--------------|
| `prompt`      | string | —       | 8000 chars   |
| `max_tokens`  | int    | 256     | `MAX_NEW_TOKENS` |
| `temperature` | float  | 0.7     | 2.0          |
| `top_p`       | float  | 0.95    | 1.0          |

### `DELETE /model`
Unload the current model and free GPU memory.

```bash
curl -X DELETE http://localhost:5000/model \
  -H "Authorization: Bearer $API_KEY"
```

## File Structure

```
ml_inference/
├── app.py                Flask entry point — all routes
├── model_manager.py      Thread-safe state machine + vLLM wrapper
├── requirements.txt
├── .env.example
├── prd.md                Product requirements
├── architecture.json     Architecture design
├── threat_model.md       Threat model (CWE-22, CWE-502, CWE-400, CWE-918)
├── uploads/              Temporary zip storage (auto-deleted after extraction)
├── models/               Extracted model directories (one per model_id)
├── templates/
│   └── index.html        Web UI
└── static/
    └── style.css
```

## Security Notes

| Control | Implementation |
|---|---|
| Zip-slip prevention | Every entry path resolved + asserted within target dir |
| Decompression bomb | Cumulative uncompressed size tracked during extraction |
| Pickle/RCE prevention | `.pkl/.pt/.pth` extensions blocked before any load |
| Unsafe model code | `trust_remote_code=False` always; architecture allowlist |
| Timing-safe auth | `hmac.compare_digest()` for API key comparison |
| No SSRF | No user-supplied URLs are fetched; upload-only model ingestion |
| TOCTOU prevention | Single ZipFile handle shared between validate + extract |
| Concurrent upload guard | State machine rejects uploads while another is in progress |
