# Threat Model — ML Model Inference API

## 1. Global Security Context

**Trust Boundaries**
- HTTP request body (`/upload` multipart, `/infer` JSON) — fully untrusted
- ZIP archive contents — untrusted; entries can contain crafted paths, symlinks, or malicious file types
- Model files inside ZIP — untrusted binary data; certain formats execute code on load
- vLLM subprocess / GPU context — trusted once loaded, but input to it must be validated
- Environment variables (`API_KEY`, `MODEL_DIR`) — trusted operator-controlled config
- File system (`models/`) — must be isolated; no user-controlled path components

**Key Assets**
- Server file system (arbitrary write via zip-slip → RCE)
- GPU / host memory (exhaustion via oversized model or prompt flood)
- Host OS (code execution via malicious pickle/PyTorch files)
- API key (compromise allows arbitrary model upload and inference)
- Other tenants' data (if deployed in shared environment)

**Auth Model**
- Single static API key via `Authorization: Bearer` header
- All endpoints except `GET /` require valid key
- No per-user roles — single operator assumed

---

## 2. Function-Level Threats

### Function: `app.py:upload()`
*Role*: Receives `model.zip`, validates, triggers async extraction + load  
*Untrusted inputs*: `request.files['model']`, filename, Content-Length  
*Security-relevant operations*: file write to disk, zip extraction, model load trigger  
*Threats*:
- **T1: Zip-Slip Path Traversal (CWE-22)** — A zip entry named `../../app.py` or `../../../etc/cron.d/backdoor` extracts outside `models/<uuid>/`, overwriting arbitrary files. On Linux this can overwrite startup scripts or the app itself.
- **T2: Zip bomb / decompression bomb (CWE-400)** — A 42 KB zip expands to 4.5 GB, exhausting disk and memory during extraction, causing OOM or disk-full DoS.
- **T3: Malicious filename in Content-Disposition** — A crafted filename like `shell.php` or `../../.bashrc` used as the extraction target if the original name is preserved on disk.
- **T4: Oversized upload bypassing Content-Length** — Chunked transfer encoding can send more bytes than the declared Content-Length, bypassing a naive size check at header-read time.

*Protections*:
- Resolve every zip entry path: `assert resolved.startswith(target_dir)` before writing
- Track cumulative uncompressed size during extraction; abort if it exceeds `MAX_EXTRACT_BYTES`
- Rename upload to `<uuid>.zip` immediately — discard original filename entirely
- Enforce upload limit via `werkzeug` `max_content_length` AND streaming byte count

---

### Function: `model_manager.py:validate_zip()`
*Role*: Inspects zip contents before any extraction  
*Untrusted inputs*: Zip entry names, entry types, entry sizes  
*Security-relevant operations*: `zipfile.ZipFile` open, entry enumeration  
*Threats*:
- **T5: Dangerous file deserialization (CWE-502)** — A model zip containing `*.pkl`, `*.pickle`, or `*.pt` files. `torch.load()` without `weights_only=True` executes arbitrary Python via pickle protocol. An attacker-controlled model zip becomes an RCE vector when the server loads it.
- **T6: Symlink escape** — A zip entry of type symlink pointing to `/etc/passwd` or `../secret`; extracting it creates a symlink that subsequent file reads follow outside the sandbox.
- **T7: Unicode / null-byte path confusion** — Entry names containing `\x00`, `..` in Unicode normalised form, or Windows path separators (`..\\`) that bypass string-level path checks but are interpreted by the OS as directory traversal.

*Protections*:
- Blocklist dangerous extensions: `.pkl`, `.pickle`, `.pt`, `.pth`, `.npy` (numpy pickle), `.bin` only allowed if accompanied by `config.json` (HuggingFace format signal)
- Require `safetensors` format: at least one `*.safetensors` file must be present
- Skip (not error on) symlink entries: `if info.is_symlink(): continue`
- Normalise entry name: `posixpath.normpath(name)`, check for `..` component after normalisation

---

### Function: `model_manager.py:safe_extract()`
*Role*: Physically extracts validated zip entries to `models/<uuid>/`  
*Untrusted inputs*: Zip entry file data (bytes)  
*Security-relevant operations*: `open()` + `shutil.copyfileobj()` per entry  
*Threats*:
- **T8: TOCTOU — zip contents change between validate and extract (CWE-362)** — If `validate_zip` and `safe_extract` both open the zip independently, a symlink-based race can swap entries between the two calls.
- **T9: Disk exhaustion during extraction (CWE-400)** — Even with validated sizes, concurrent uploads can exhaust disk if no global quota is enforced.

*Protections*:
- Open the zip file **once** and pass the open handle to both validate and extract — eliminates TOCTOU window
- Track bytes written per extraction; abort and delete partial dir on limit exceeded
- Allow only one model upload at a time (state machine lock); reject concurrent uploads with 409

---

### Function: `model_manager.py:load_model_async()` — vLLM load
*Role*: Calls `vllm.LLM(model=model_path)` in a background thread  
*Untrusted inputs*: `model_path` (derived from extraction, trusted only if extraction was safe)  
*Security-relevant operations*: vLLM model load (HuggingFace tokenizer + weights), GPU allocation  
*Threats*:
- **T10: Malicious `tokenizer_config.json` / `config.json` (CWE-502)** — HuggingFace's `AutoTokenizer` evaluates `tokenizer_class` fields and can instantiate arbitrary Python classes if a crafted config references a local module. A model zip can include a malicious `tokenizer_config.json`.
- **T11: GPU memory exhaustion (CWE-400)** — Loading a model larger than available VRAM crashes the process or makes the server unresponsive to other requests.
- **T12: Arbitrary code in model init scripts** — Some HuggingFace repos include `modeling_*.py` custom code loaded via `trust_remote_code=True`. If this flag is set, any Python in the zip executes during load.

*Protections*:
- Never set `trust_remote_code=True` in `vllm.LLM()`
- Validate `config.json` before load: check `architectures` field against a known-safe allowlist
- Set `gpu_memory_utilization` cap (e.g. 0.85) to prevent OOM cascade
- Load in daemon thread with timeout; kill thread and reset state on timeout

---

### Function: `app.py:infer()`
*Role*: Accepts a prompt and returns generated text  
*Untrusted inputs*: `request.json['prompt']`, `max_tokens`, `temperature`, `top_p`  
*Security-relevant operations*: `ModelManager.generate()` → vLLM `llm.generate()`  
*Threats*:
- **T13: Prompt-based resource exhaustion (CWE-400)** — An extremely long prompt (millions of tokens) fills the KV cache and hangs the inference server, blocking all other requests.
- **T14: Parameter abuse — max_tokens override** — Client sends `max_tokens=100000`, forcing generation of massive output, exhausting GPU time.
- **T15: Timing side-channel on API key check** — `==` comparison on the API key leaks key length via timing; with enough requests an attacker can reconstruct the key character by character.
- **T16: Inference while model is loading (CWE-362)** — If state is checked and then model is unloaded concurrently, `llm` reference becomes None between the check and the `.generate()` call (race condition).

*Protections*:
- Hard cap prompt length: `len(prompt) > MAX_PROMPT_CHARS` → 400 error
- Server-side cap on `max_tokens`: `min(requested, MAX_NEW_TOKENS)` — client cannot override the server ceiling
- Use `hmac.compare_digest()` for API key comparison — constant-time
- Hold `self._lock` during the entire generate call; unload waits for the lock

---

### Function: `app.py:require_api_key()`
*Role*: Authenticates all API requests  
*Untrusted inputs*: `Authorization` HTTP header  
*Security-relevant operations*: String comparison against `API_KEY` env var  
*Threats*:
- **T17: Missing authentication on endpoint (CWE-306)** — If the decorator is accidentally omitted, `/upload` or `/infer` becomes public, allowing anyone to upload arbitrary model zips or run inference.
- **T18: API key in logs / error responses** — Flask debug mode or unhandled exceptions may echo request headers including the Authorization value into logs or HTTP responses.
- **T19: Brute-force of short API key** — A 6-character API key has ~56 billion combinations — feasible with no rate limiting.

*Protections*:
- Apply decorator to 100% of state-changing endpoints; assert in tests
- `app.config['PROPAGATE_EXCEPTIONS'] = False` in production; never return raw exception text
- Enforce minimum API key length of 32 random hex chars; document in `.env.example`
- Log only `Authorization: Bearer [REDACTED]`, never the key value

---

## 3. Project Integrity

**Critical Risks**

1. **`trust_remote_code=True` in vLLM** — This single flag converts any uploaded model zip into arbitrary code execution on the host. It must never be set, and its absence should be asserted in tests.

2. **Pickle files in model zip** — `torch.load()` without `weights_only=True` is equivalent to `eval()` on attacker-supplied bytes. The zip validator must block `.pt`/`.pkl`/`.pickle` files before any load attempt.

3. **Zip-slip overwriting `app.py`** — If the path guard is bypassed (e.g. Unicode normalisation edge case), an attacker can overwrite the running application, achieving persistent RCE that survives model deletion.

**Top 3 Attack Vectors**
1. Upload zip with `../../app.py` entry → overwrite Flask app → RCE (T1)
2. Upload zip containing `model.pkl` with `__reduce__` payload → RCE on vLLM load (T5)
3. Upload zip with `trust_remote_code` model + malicious `modeling_custom.py` — if flag ever enabled (T12)

**Recommended Additions**
- Run vLLM model loading in a separate sandboxed process (e.g. `multiprocessing` with restricted permissions) so a malicious model cannot access the Flask app's memory
- Add rate limiting on `/infer` (e.g. 60 req/min per API key) to prevent GPU DoS
- Compute SHA-256 of uploaded zip and log it alongside model_id for auditability
- Scan model directory with `safetensors` header validator before passing to vLLM
