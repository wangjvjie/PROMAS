"""Main application entry point.

Utilizes the factory pattern to initialize Flask, register blueprints,
apply security middleware, and expose the WSGI callable.
"""

from app import create_app, setup_security_headers, register_blueprints
from app.config import Config


def main() -> None:
    """Development server entry point that instantiates the app and runs it
    with debug disabled in production mode.
    """
    app = create_app()
    # Debug mode is controlled by Config.FLASK_ENV inside create_app
    debug = app.config.get("DEBUG", False)
    app.run(host="0.0.0.0", port=5000, debug=debug)


if __name__ == "__main__":
    main()
