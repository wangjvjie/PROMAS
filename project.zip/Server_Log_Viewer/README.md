# Server Log Viewer

A secure, web-based log viewer for system administrators to browse, inspect, and search through server log files located in `/var/log` without requiring direct SSH access.

## Features

- **Log Browsing**: Paginated dashboard listing all readable `.log` files in the configured directory
- **Log Viewing**: Streamed content display with line numbers and log-level syntax highlighting
- **Keyword Search**: Safe, regex-based search across log files with paginated results
- **Authentication**: Session-based admin login with HTTP-only, Secure, SameSite cookies
- **Rate Limiting**: Endpoint-level throttling to prevent scraping and DoS attacks
- **Audit Logging**: Structured logging of all file access and search queries

## Architecture

```
┌─────────────┐      ┌─────────────┐      ┌──────────────┐
│   Client    │─────▶│    Nginx    │─────▶│   Gunicorn   │
│  (Browser)  │      │  (TLS/Proxy)│      │   (Flask)    │
└─────────────┘      └─────────────┘      └──────┬───────┘
                                                  │
                                                  ▼
                                          ┌──────────────┐
                                          │  /var/log     │
                                          │  (read-only)  │
                                          └──────────────┘
```

### Project Structure

```
.
├── app.py                      # WSGI entry point
├── gunicorn.conf.py            # Production server config
├── docker-compose.yml          # Service orchestration
├── Dockerfile                  # Container build definition
├── nginx.conf                  # Reverse proxy config
├── requirements.txt            # Python dependencies
├── .env                        # Runtime configuration (do not commit)
└── app/
    ├── __init__.py             # App factory & blueprint registration
    ├── config.py               # Configuration loader
    ├── extensions.py           # Flask-Login & Flask-Limiter registry
    ├── auth/
    │   ├── __init__.py         # Auth blueprint barrel
    │   ├── models.py           # AdminUser model & loader
    │   └── routes.py           # Login/logout handlers
    ├── logs/
    │   ├── __init__.py         # Logs blueprint barrel
    │   ├── routes.py           # Index, view, search endpoints
    │   └── utils.py            # Path validation & search utilities
    ├── templates/
    │   ├── base.html           # Base layout
    │   ├── login.html          # Login form
    │   ├── index.html          # Log file dashboard
    │   ├── view.html           # Log content viewer
    │   └── search.html         # Search interface & results
    └── static/css/
        └── style.css           # Global stylesheet
```

## Security Design

### Authentication & Authorization
- Session-based authentication via `Flask-Login`
- HTTP-only, Secure, SameSite=Strict cookies
- Password hashing with `werkzeug.security` (constant-time comparison)
- Session regeneration on login, server-side invalidation on logout
- Admin-only access enforced on all `/logs/*` routes

### Input Validation & Path Traversal Prevention
- Strict filename allowlist generated from `/var/log` contents
- Rejection of `..`, `/`, `\`, and null bytes in path parameters
- `pathlib.Path.resolve()` with directory containment verification
- Symlink detection and rejection

### Command Injection Mitigation
- Native Python `re` module for search (no `subprocess` or `shell=True`)
- Regex complexity limits and timeout protection
- Keyword length and character set restrictions

### Rate Limiting & Anti-Abuse
- 30 requests/minute for log viewing
- 10 requests/minute for search operations
- Progressive delays on authentication failures
- Pagination limits (max 1000 pages, 200 lines per page)

### Infrastructure Hardening
- Non-root container execution (`appuser`)
- Read-only bind mount for `/var/log`
- HTTPS termination via Nginx with strict security headers:
  - Content-Security-Policy (CSP)
  - HTTP Strict-Transport-Security (HSTS)
  - X-Frame-Options: DENY
  - X-Content-Type-Options: nosniff
- Secrets managed via environment variables (`.env`)
- Debug mode disabled in production

## Prerequisites

- Python 3.11+
- Docker & Docker Compose (for containerized deployment)
- Access to `/var/log` (or a custom log directory)

## Installation & Setup

### Option 1: Docker Compose (Recommended)

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd log-viewer
   ```

2. **Configure environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your settings:
   # - SECRET_KEY: Generate a strong random key
   # - ADMIN_USERNAME: Your admin username
   # - ADMIN_PASSWORD_HASH: Hash generated via:
   #   python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('your-password'))"
   # - LOG_DIR: Path to log directory (default: /var/log)
   ```

3. **Start the application**
   ```bash
   docker-compose up -d
   ```

4. **Access the application**
   - Open `https://localhost` in your browser
   - Log in with your admin credentials

### Option 2: Local Development

1. **Create a virtual environment**
   ```bash
   python3.11 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env
   # Edit .env as described above
   ```

4. **Run the development server**
   ```bash
   python app.py
   ```

5. **Access the application**
   - Open `http://localhost:5000` in your browser

## Configuration

All configuration is managed via environment variables in the `.env` file:

| Variable | Description | Default |
|----------|-------------|---------|
| `SECRET_KEY` | Flask session encryption key | (required) |
| `ADMIN_USERNAME` | Admin login username | `admin` |
| `ADMIN_PASSWORD_HASH` | Bcrypt-hashed admin password | (required) |
| `LOG_DIR` | Directory containing log files | `/var/log` |
| `FLASK_ENV` | Application environment | `production` |
| `RATELIMIT_DEFAULT` | Default rate limit | `30 per minute` |

### Generating a Password Hash

```bash
python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('your-secure-password'))"
```

## Usage

### Log Dashboard (`/`)
- Lists all readable `.log` files in the configured directory
- Displays file size and last modification date
- Paginated for large directories

### Log Viewer (`/logs/view/<filename>`)
- Click any log file from the dashboard to view its contents
- Content is displayed with line numbers and color-coded log levels
- Navigate between pages using pagination controls

### Search (`/logs/search/<filename>`)
- Enter a keyword in the search form on the view page
- Results are paginated and highlight matching lines
- Search is case-insensitive and uses safe regex patterns

## API Endpoints

| Method | Path | Description | Auth Required | Rate Limit |
|--------|------|-------------|---------------|------------|
| GET | `/` | Log file dashboard | Yes | 30/min |
| GET | `/logs/view/<filename>` | View log file contents | Yes | 30/min |
| POST | `/logs/search/<filename>` | Search log file | Yes | 10/min |
| GET/POST | `/auth/login` | Admin login | No | 10/min |
| POST | `/auth/logout` | Admin logout | Yes | 30/min |

## Deployment

### Production Checklist

- [ ] Generate a strong `SECRET_KEY` (minimum 32 random bytes)
- [ ] Set `ADMIN_PASSWORD_HASH` to a secure, unique password
- [ ] Ensure `/var/log` is mounted as read-only (`:ro`)
- [ ] Configure valid TLS certificates for Nginx
- [ ] Set `FLASK_ENV=production`
- [ ] Verify debug mode is disabled
- [ ] Review Nginx security headers
- [ ] Enable structured audit logging
- [ ] Set up log rotation for application logs
- [ ] Configure firewall rules to restrict access

### Docker Compose Production Example

```yaml
services:
  app:
    build: .
    restart: unless-stopped
    volumes:
      - /var/log:/var/log:ro
    env_file:
      - .env
    networks:
      - internal

  nginx:
    image: nginx:alpine
    restart: unless-stopped
    ports:
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./certs:/etc/nginx/certs:ro
    depends_on:
      - app
    networks:
      - internal

networks:
  internal:
    driver: bridge
```

## Troubleshooting

### Common Issues

1. **Permission denied when reading logs**
   - Ensure the container user has read access to `/var/log`
   - Verify the volume mount includes `:ro` flag

2. **Login fails with valid credentials**
   - Check that `ADMIN_PASSWORD_HASH` is correctly generated
   - Verify `SECRET_KEY` is set and consistent across restarts

3. **Rate limit exceeded**
   - Adjust `RATELIMIT_DEFAULT` in `.env` if needed
   - Check for automated scripts or bots hitting endpoints

4. **Search returns no results**
   - Verify the log file contains the keyword
   - Check for special characters in the search term (regex metacharacters are escaped)

### Viewing Application Logs

```bash
docker-compose logs -f app
```

## License

This project is provided as-is for internal administrative use. Ensure compliance with your organization's security policies before deployment.

## Contributing

Security vulnerabilities should be reported privately. Please review the threat model and architecture documentation before proposing changes to authentication, input validation, or file access logic.
