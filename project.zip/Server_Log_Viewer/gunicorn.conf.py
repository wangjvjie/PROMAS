import multiprocessing
import os

# WSGI Application
wsgi_app = "app:create_app()"

# Server Socket
bind = os.environ.get("GUNICORN_BIND", "0.0.0.0:8000")
backlog = 2048

# Worker Processes
workers = int(os.environ.get("GUNICORN_WORKERS", max(2, multiprocessing.cpu_count() * 2 + 1)))
worker_class = "sync"
timeout = 30
keepalive = 2

# Logging
accesslog = os.environ.get("GUNICORN_ACCESS_LOG", "-")
errorlog = os.environ.get("GUNICORN_ERROR_LOG", "-")
loglevel = os.environ.get("GUNICORN_LOG_LEVEL", "info")
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# Process Naming
proc_name = "logviewer"

# Security & Hardening
limit_request_line = 4094
limit_request_fields = 100
limit_request_field_size = 8190
graceful_timeout = 30
max_requests = 1000
max_requests_jitter = 50
preload_app = True