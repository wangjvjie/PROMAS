"""Defines the admin user model for Flask-Login and the user loader callback.

Provides a single-admin credential store backed by environment variables,
with constant-time password verification and Flask-Login compatibility.
"""

from flask_login import UserMixin
from werkzeug.security import check_password_hash

from app.config import Config
from app.extensions import ExtensionRegistry


class AdminUser(UserMixin):
    """Represents the single administrator user for Flask-Login.

    Attributes:
        id: Unique identifier for the user (string).
        username: Login username.
        password_hash: Bcrypt/SHA256 hashed password for verification.
    """

    def __init__(self, id: str, username: str, password_hash: str) -> None:
        self.id = id
        self.username = username
        self.password_hash = password_hash

    def check_password(self, password: str) -> bool:
        """Verify a plaintext password against the stored hash.

        Uses werkzeug's constant-time comparison to prevent timing attacks.

        Args:
            password: Plaintext password to verify.

        Returns:
            True if the password matches, False otherwise.
        """
        return check_password_hash(self.password_hash, password)

    def get_id(self) -> str:
        """Return the user ID as a string for Flask-Login session management.

        Returns:
            The user's unique identifier.
        """
        return str(self.id)


# Singleton admin user instance, lazily initialized from environment config
_admin_user: AdminUser | None = None


def _get_admin_user() -> AdminUser:
    """Retrieve or create the singleton admin user from environment config.

    Returns:
        The configured AdminUser instance.
    """
    global _admin_user
    if _admin_user is None:
        config = Config()
        _admin_user = AdminUser(
            id="1",
            username=config.ADMIN_USERNAME,
            password_hash=config.ADMIN_PASSWORD_HASH,
        )
    return _admin_user


def load_user(user_id: str) -> AdminUser | None:
    """Flask-Login user loader callback.

    Retrieves the authenticated admin user by ID from the secure credential
    store. Only returns the user if the ID matches the configured admin.

    Args:
        user_id: The user ID string from the session cookie.

    Returns:
        The AdminUser instance if the ID is valid, None otherwise.
    """
    admin = _get_admin_user()
    if admin.get_id() == user_id:
        return admin
    return None


def setup_login_manager(registry: ExtensionRegistry) -> None:
    """Configure the Flask-Login manager with security settings.

    Sets the user loader callback, unauthorized handler, session protection,
    and cookie security flags.

    Args:
        registry: The ExtensionRegistry containing the login_manager instance.
    """
    registry.login_manager.user_loader(load_user)
    registry.login_manager.login_view = "auth.login"
    registry.login_manager.login_message = "Please log in to access this resource."
    registry.login_manager.login_message_category = "warning"
    registry.login_manager.session_protection = "strong"
