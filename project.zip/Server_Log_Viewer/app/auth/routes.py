"""Authentication routes for admin login and logout.

Handles credential validation, session management, and secure cookie issuance.
Implements CSRF protection and session fixation mitigation.
"""

import os
import logging
from typing import Union
from flask import request, redirect, url_for, render_template, flash, session, abort, Response
from flask_login import login_user, logout_user, current_user

from app.auth import auth_bp
from app.auth.models import _get_admin_user

logger = logging.getLogger(__name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login() -> Union[Response, str]:
    """Handles GET/POST for admin login, validates credentials against hashed store,
    and establishes HTTP-only secure session cookies."""
    if current_user.is_authenticated:
        return redirect(url_for("logs.index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        csrf_token = request.form.get("csrf_token")

        # CSRF validation
        if not csrf_token or csrf_token != session.get("csrf_token"):
            abort(403)

        admin = _get_admin_user()
        # Constant-time password comparison via werkzeug
        if admin.username == username and admin.check_password(password):
            login_user(admin)
            session.permanent = True
            # Prevent session fixation by clearing and regenerating session state
            old_csrf = session.get("csrf_token")
            session.clear()
            session["csrf_token"] = old_csrf or os.urandom(24).hex()
            logger.info("Successful login for user: %s", username)
            return redirect(url_for("logs.index"))

        logger.warning("Failed login attempt for user: %s", username)
        flash("Invalid username or password.", "error")

    # Generate CSRF token for form rendering
    if "csrf_token" not in session:
        session["csrf_token"] = os.urandom(24).hex()

    return render_template("login.html", csrf_token=session["csrf_token"])


@auth_bp.route("/logout", methods=["POST"])
def logout() -> Union[Response, str]:
    """Invalidates the current session, clears authentication cookies,
    and redirects to the login page."""
    csrf_token = request.form.get("csrf_token")
    if not csrf_token or csrf_token != session.get("csrf_token"):
        abort(403)

    logout_user()
    session.clear()
    logger.info("User logged out")
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))