"""Authentication blueprint barrel module.

Re-exports exactly: auth_bp, User, login_required, current_user.
Provides centralized access to auth routing, session management, and credential validation.
"""

from flask import Blueprint, Flask
from flask_login import LoginManager, login_required, current_user

from app.auth.models import AdminUser, setup_login_manager as _setup_login_manager

# Module-level registry reference, set by the application factory
_registry = None


def set_registry(registry) -> None:
    """Set the ExtensionRegistry reference for use by setup_login_manager.

    Called by the application factory during initialization.

    Args:
        registry: The ExtensionRegistry instance from app/extensions.py.
    """
    global _registry
    _registry = registry


# Authentication blueprint with URL prefix
auth_bp = Blueprint("auth", __name__, url_prefix="/auth")

# Import routes to register handlers with the blueprint
# Routes must be imported after blueprint creation to avoid circular imports
from app.auth import routes  # noqa: E402, F401

# Re-exports as specified by architecture
User = AdminUser


def get_auth_blueprint() -> Blueprint:
    """Returns the configured Flask Blueprint for authentication routes.

    The blueprint includes login, logout, and session validation handlers.

    Returns:
        The authentication Blueprint instance.
    """
    return auth_bp


def setup_login_manager(app: Flask) -> LoginManager:
    """Configures the login manager with user loader callback, unauthorized handler,
    session protection mode, and cookie security flags.

    Args:
        app: The Flask application instance.

    Returns:
        The configured LoginManager instance.
    """
    if _registry is None:
        raise RuntimeError(
            "ExtensionRegistry not set. Call set_registry() before setup_login_manager()."
        )
    _setup_login_manager(_registry)
    return _registry.login_manager
