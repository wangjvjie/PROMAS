"""Core utilities for secure log file listing, path validation, pagination, and regex-based searching."""

import os
import pathlib
import re
from typing import Tuple, List

# Pagination safety bounds
MAX_PAGE = 1000
MAX_LINES_PER_PAGE = 200
MAX_KEYWORD_LENGTH = 256
# Characters that are safe in a search keyword (alphanumeric, spaces, common punctuation)
SAFE_KEYWORD_PATTERN = re.compile(r'^[\w\s\.\-\_\:\,\;\!\?\@\#\$\%\^\&\*\(\)\[\]\{\}\/\\\'\"]+$')


def list_available_logs(log_dir: pathlib.Path) -> List[pathlib.Path]:
    """Scan the specified directory for readable .log files, filter out non-regular files,
    and return a sorted list of absolute paths.
    
    Security: Only returns regular files (not symlinks), checks readability,
    and restricts to .log extension.
    """
    available_files: List[pathlib.Path] = []
    
    if not log_dir.is_dir():
        return available_files
    
    try:
        for entry in log_dir.iterdir():
            # Skip symlinks to prevent escape attacks
            if entry.is_symlink():
                continue
            # Only regular files with .log extension
            if entry.is_file() and entry.suffix == '.log':
                # Verify readability
                if os.access(entry, os.R_OK):
                    available_files.append(entry.resolve())
    except PermissionError:
        # Gracefully handle permission issues on directory entries
        pass
    
    return sorted(available_files, key=lambda p: p.name)


def resolve_and_validate_log(filename: str, log_dir: pathlib.Path) -> pathlib.Path:
    """Sanitize the filename input, reject path traversal sequences, resolve the absolute path,
    and verify it remains within the allowed log_dir. Raises ValueError on invalid paths.
    
    Security protections:
    - Rejects null bytes, backslashes, and '..' sequences
    - Resolves symlinks and verifies containment within log_dir
    - Uses strict prefix matching on resolved paths
    """
    if not filename:
        raise ValueError("Filename cannot be empty")
    
    # Early rejection of dangerous characters
    if '\x00' in filename or '\\' in filename or '..' in filename:
        raise ValueError("Invalid filename: contains prohibited characters")
    
    # Reject absolute paths or paths with directory separators
    if filename.startswith('/') or '/' in filename:
        raise ValueError("Invalid filename: must be a simple filename, not a path")
    
    # Construct the candidate path
    log_dir_resolved = log_dir.resolve()
    candidate = log_dir_resolved / filename
    
    # Resolve to absolute path (follows symlinks)
    resolved = candidate.resolve()
    
    # Verify the resolved path is within the allowed directory
    # Use os.path.commonpath for strict containment check
    try:
        common = os.path.commonpath([str(resolved), str(log_dir_resolved)])
        if common != str(log_dir_resolved):
            raise ValueError("Path traversal detected: resolved path escapes log directory")
    except ValueError as e:
        if "Path traversal" in str(e):
            raise
        raise ValueError("Invalid path: cannot compute common path")
    
    # Verify the file exists and is a regular file (not a directory)
    if not resolved.exists():
        raise ValueError(f"File not found: {filename}")
    
    if resolved.is_symlink():
        raise ValueError("Symlinks are not allowed for security reasons")
    
    if not resolved.is_file():
        raise ValueError("Path is not a regular file")
    
    # Verify readability
    if not os.access(resolved, os.R_OK):
        raise ValueError("File is not readable")
    
    return resolved


def get_paginated_log_lines(
    filepath: pathlib.Path, 
    page: int, 
    lines_per_page: int
) -> Tuple[List[str], int]:
    """Read the specified log file efficiently, calculate pagination offsets,
    and return the requested chunk of lines along with the total line count.
    
    Security: Enforces pagination bounds to prevent resource exhaustion.
    Uses line-by-line streaming to handle large files without OOM.
    """
    # Enforce pagination bounds
    page = max(1, min(page, MAX_PAGE))
    lines_per_page = max(1, min(lines_per_page, MAX_LINES_PER_PAGE))
    
    start_line = (page - 1) * lines_per_page
    end_line = start_line + lines_per_page
    
    lines: List[str] = []
    total_lines = 0
    
    try:
        with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
            for line_num, line in enumerate(f, 1):
                total_lines = line_num
                if start_line < line_num <= end_line:
                    lines.append(line.rstrip('\n'))
                # Early termination if we've passed the requested page
                if line_num > end_line:
                    break
    except (IOError, OSError):
        # Return empty results on read errors
        pass
    
    return lines, total_lines


def search_log_lines(
    filepath: pathlib.Path, 
    keyword: str, 
    page: int, 
    lines_per_page: int
) -> Tuple[List[str], int]:
    """Compile a case-insensitive regex from the sanitized keyword, stream the log file
    line-by-line, collect matches, and return the paginated subset with the total match count.
    
    Security protections:
    - Keyword length limit to prevent ReDoS
    - Escapes regex special characters to prevent injection
    - Enforces pagination bounds
    - Line-by-line streaming to prevent memory exhaustion
    """
    # Enforce pagination bounds
    page = max(1, min(page, MAX_PAGE))
    lines_per_page = max(1, min(lines_per_page, MAX_LINES_PER_PAGE))
    
    # Sanitize keyword
    if not keyword or len(keyword) > MAX_KEYWORD_LENGTH:
        return [], 0
    
    # Escape regex special characters to prevent ReDoS and injection
    safe_keyword = re.escape(keyword)
    
    try:
        # Compile case-insensitive pattern
        pattern = re.compile(safe_keyword, re.IGNORECASE)
    except re.error:
        return [], 0
    
    matches: List[str] = []
    total_matches = 0
    start_match = (page - 1) * lines_per_page
    end_match = start_match + lines_per_page
    
    try:
        with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
            for line in f:
                if pattern.search(line):
                    total_matches += 1
                    # Only collect matches within the requested page
                    if start_match < total_matches <= end_match:
                        matches.append(line.rstrip('\n'))
                    # Early termination if we've collected enough matches
                    if total_matches > end_match:
                        break
    except (IOError, OSError):
        pass
    
    return matches, total_matches
