"""Barrel file for the logs module.

Re-exports: get_logs_blueprint, setup_logs_rate_limiter.
Provides centralized access to log viewing, searching, and rate limiting configuration.
"""

from flask import Blueprint, Flask

from app.extensions import ExtensionRegistry

# Module-level registry reference, set by the application factory
_registry = None


def set_registry(registry: ExtensionRegistry) -> None:
    """Set the ExtensionRegistry reference for use by rate limiter setup.

    Called by the application factory during initialization.

    Args:
        registry: The ExtensionRegistry instance from app/extensions.py.
    """
    global _registry
    _registry = registry


# Logs blueprint with URL prefix
logs_bp = Blueprint("logs", __name__, url_prefix="/logs")

# Import routes to register handlers with the blueprint
# Routes must be imported after blueprint creation to avoid circular imports
from app.logs import routes  # noqa: E402, F401


def get_logs_blueprint() -> Blueprint:
    """Factory function that creates, configures, and returns the logs blueprint
    with all registered route handlers.

    Returns:
        The logs Blueprint instance.
    """
    return logs_bp