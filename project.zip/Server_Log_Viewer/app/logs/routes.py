"""Core log management endpoints: listing, viewing, and searching with strict path validation and audit logging."""

import logging
import pathlib
from datetime import datetime, timezone

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)
from flask_login import login_required

from app.extensions import ExtensionRegistry
from app.logs.utils import (
    get_paginated_log_lines,
    list_available_logs,
    resolve_and_validate_log,
    search_log_lines,
)

# Import the blueprint from the parent package
# This is safe because __init__.py creates the blueprint before importing this module
from app.logs import logs_bp
from app.extensions import limiter

# Configure audit logger
audit_logger = logging.getLogger("log_viewer.audit")

# Default pagination settings
DEFAULT_LINES_PER_PAGE = 50


@logs_bp.route("/")
@logs_bp.route("/<int:page>")
@login_required
@limiter.limit("30 per minute")
def index(page: int = 1) -> str:
    """Scans the allowed log directory, filters readable files, and renders a paginated index table.
    
    Security: Requires authentication, enforces pagination bounds,
    and only exposes minimal file metadata.
    """
    log_dir = pathlib.Path(current_app.config.get("LOG_DIR", "/var/log"))
    
    try:
        available_logs = list_available_logs(log_dir)
    except Exception as e:
        audit_logger.warning(f"Failed to list logs: {e}")
        flash("Error accessing log directory.", "error")
        return render_template("index.html", logs=[], page=1, total_pages=0)
    
    # Paginate the log files list
    logs_per_page = 20
    total_logs = len(available_logs)
    total_pages = max(1, (total_logs + logs_per_page - 1) // logs_per_page)
    page = max(1, min(page, total_pages))
    
    start_idx = (page - 1) * logs_per_page
    end_idx = start_idx + logs_per_page
    page_logs = available_logs[start_idx:end_idx]
    
    # Build log metadata for template
    log_entries = []
    for log_path in page_logs:
        try:
            stat = log_path.stat()
            log_entries.append({
                "name": log_path.name,
                "size": stat.st_size,
                "modified": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
            })
        except OSError:
            continue
    
    audit_logger.info(f"User {request.remote_user or 'anonymous'} listed logs (page {page})")
    
    return render_template(
        "index.html",
        logs=log_entries,
        page=page,
        total_pages=total_pages,
        total_logs=total_logs,
    )


@logs_bp.route("/view/<filename>")
@login_required
@limiter.limit("30 per minute")
def view(filename: str) -> str:
    """Validates the requested filename against the directory allowlist, resolves the safe path,
    and streams file content with line numbers.
    
    Security: Uses resolve_and_validate_log to prevent path traversal,
    enforces pagination to prevent memory exhaustion, and auto-escapes output in templates.
    """
    log_dir = pathlib.Path(current_app.config.get("LOG_DIR", "/var/log"))
    page = request.args.get("page", 1, type=int)
    lines_per_page = request.args.get("lines", DEFAULT_LINES_PER_PAGE, type=int)
    
    try:
        filepath = resolve_and_validate_log(filename, log_dir)
    except ValueError as e:
        audit_logger.warning(f"Path validation failed for '{filename}': {e}")
        flash(f"Invalid log file: {e}", "error")
        return redirect(url_for("logs.index"))
    
    try:
        lines, total_lines = get_paginated_log_lines(filepath, page, lines_per_page)
    except Exception as e:
        audit_logger.error(f"Failed to read log file '{filename}': {e}")
        flash("Error reading log file.", "error")
        return redirect(url_for("logs.index"))
    
    total_pages = max(1, (total_lines + lines_per_page - 1) // lines_per_page)
    page = max(1, min(page, total_pages))
    
    audit_logger.info(f"User viewed log '{filename}' (page {page}, {len(lines)} lines)")
    
    return render_template(
        "view.html",
        filename=filename,
        lines=lines,
        page=page,
        total_pages=total_pages,
        total_lines=total_lines,
        lines_per_page=lines_per_page,
    )


@logs_bp.route("/search/<filename>", methods=["GET", "POST"])
@login_required
@limiter.limit("10 per minute")
def search(filename: str) -> str:
    """Accepts a POST keyword, sanitizes input, executes a safe regex/mmap search on the validated log file,
    and returns paginated matches.
    
    Security: Validates path, sanitizes keyword, uses escaped regex patterns,
    enforces pagination bounds, and auto-escapes results in templates.
    """
    log_dir = pathlib.Path(current_app.config.get("LOG_DIR", "/var/log"))
    page = request.args.get("page", 1, type=int)
    lines_per_page = request.args.get("lines", DEFAULT_LINES_PER_PAGE, type=int)
    
    try:
        filepath = resolve_and_validate_log(filename, log_dir)
    except ValueError as e:
        audit_logger.warning(f"Path validation failed for search '{filename}': {e}")
        flash(f"Invalid log file: {e}", "error")
        return redirect(url_for("logs.index"))
    
    keyword = ""
    matches = []
    total_matches = 0
    total_pages = 0
    
    if request.method == "POST":
        keyword = request.form.get("keyword", "").strip()
        
        if not keyword:
            flash("Please enter a search keyword.", "warning")
        else:
            try:
                matches, total_matches = search_log_lines(filepath, keyword, page, lines_per_page)
                total_pages = max(1, (total_matches + lines_per_page - 1) // lines_per_page)
                page = max(1, min(page, total_pages))
                
                audit_logger.info(
                    f"User searched log '{filename}' for '{keyword[:50]}...' "
                    f"(page {page}, {len(matches)}/{total_matches} matches)"
                )
            except Exception as e:
                audit_logger.error(f"Search failed for '{filename}': {e}")
                flash("Error performing search.", "error")
    
    return render_template(
        "search.html",
        filename=filename,
        keyword=keyword,
        matches=matches,
        page=page,
        total_pages=total_pages,
        total_matches=total_matches,
        lines_per_page=lines_per_page,
    )