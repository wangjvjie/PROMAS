"""Application factory and central barrel module.

Re-exports exactly: Config, login_manager, limiter, auth_bp, logs_bp.
Initializes the Flask application instance, wires extensions, and registers blueprints.
"""

from flask import Flask, Response, redirect, render_template, url_for
from flask_login import current_user

from app.config import Config
from app.extensions import ExtensionRegistry
from app.auth import (
    get_auth_blueprint,
    setup_login_manager,
    set_registry as set_auth_registry,
    auth_bp,
)
from app.logs import (
    get_logs_blueprint,
    set_registry as set_logs_registry,
    logs_bp,
)

# Module-level re-exports (populated during create_app)
login_manager = None
limiter = None


def create_app(config_class: type[Config] | None = None) -> Flask:
    """Factory function that instantiates the Flask application, applies secure
    configuration, initializes extensions, and registers modular blueprints.

    Args:
        config_class: Optional custom configuration class. Defaults to Config.

    Returns:
        Configured Flask application instance.
    """
    global login_manager, limiter

    app = Flask(__name__)

    # Load configuration
    cfg = (config_class or Config)()
    app.config["SECRET_KEY"] = cfg.SECRET_KEY
    app.config["SESSION_COOKIE_HTTPONLY"] = cfg.SESSION_COOKIE_HTTPONLY
    app.config["SESSION_COOKIE_SECURE"] = cfg.SESSION_COOKIE_SECURE
    app.config["SESSION_COOKIE_SAMESITE"] = cfg.SESSION_COOKIE_SAMESITE
    app.config["PERMANENT_SESSION_LIFETIME"] = cfg.PERMANENT_SESSION_LIFETIME
    app.config["LOG_DIR"] = cfg.LOG_DIR
    app.config["FLASK_ENV"] = cfg.FLASK_ENV
    app.config["RATELIMIT_DEFAULT"] = cfg.RATELIMIT_DEFAULT

    # Disable debug in production
    app.config["DEBUG"] = cfg.FLASK_ENV != "production"

    # Initialize extensions
    registry = ExtensionRegistry()
    registry.init_app(app)

    # Expose for re-export
    login_manager = registry.login_manager
    limiter = registry.limiter

    # Wire registries into submodules
    set_auth_registry(registry)
    set_logs_registry(registry)

    # Configure login manager
    setup_login_manager(app)

    # Register blueprints
    register_blueprints(app)
    register_entrypoint_routes(app)

    # Apply security headers
    setup_security_headers(app)

    # Register centralized error handlers
    _register_error_handlers(app)

    return app


def setup_security_headers(app: Flask) -> None:
    """Attaches an after-request hook to inject strict HTTP security headers.

    Headers include:
    - Content-Security-Policy: Restricts resource loading to same-origin.
    - Strict-Transport-Security: Enforces HTTPS for 1 year.
    - X-Frame-Options: Prevents clickjacking.
    - X-Content-Type-Options: Prevents MIME-type sniffing.
    - Referrer-Policy: Limits referrer information.
    - Permissions-Policy: Restricts browser features.

    Args:
        app: The Flask application instance.
    """

    @app.after_request
    def add_security_headers(response: Response) -> Response:
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self'; font-src 'self'; frame-ancestors 'none'"
        )
        response.headers["Strict-Transport-Security"] = (
            "max-age=31536000; includeSubDomains"
        )
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = (
            "camera=(), microphone=(), geolocation=()"
        )
        # Remove server header to avoid information disclosure
        response.headers.pop("Server", None)
        return response


def register_blueprints(app: Flask) -> None:
    """Imports and registers the authentication and log viewing blueprints
    with their respective URL prefixes.

    Args:
        app: The Flask application instance.
    """
    app.register_blueprint(get_auth_blueprint())
    app.register_blueprint(get_logs_blueprint())


def register_entrypoint_routes(app: Flask) -> None:
    """Register compatibility routes for the application entrypoints.

    The project documentation and login flow expect `/` and `/login` to be
    reachable directly, while the blueprints are mounted under `/logs` and
    `/auth`. These aliases preserve the modular blueprint structure without
    breaking the public-facing URLs.

    Args:
        app: The Flask application instance.
    """

    @app.route("/")
    def home():
        if current_user.is_authenticated:
            return redirect(url_for("logs.index"))
        return redirect(url_for("login_alias"))

    @app.route("/login", methods=["GET", "POST"])
    def login_alias():
        return app.view_functions["auth.login"]()

    @app.route("/logout", methods=["POST"])
    def logout_alias():
        return app.view_functions["auth.logout"]()


def _register_error_handlers(app: Flask) -> None:
    """Registers centralized error handlers that return generic, safe messages
    without leaking stack traces or internal details.

    Args:
        app: The Flask application instance.
    """

    @app.errorhandler(403)
    def forbidden(error):
        if app.config.get("DEBUG"):
            raise error
        return render_template("error.html", code=403, message="Access Denied"), 403

    @app.errorhandler(404)
    def not_found(error):
        if app.config.get("DEBUG"):
            raise error
        return render_template("error.html", code=404, message="Page Not Found"), 404

    @app.errorhandler(429)
    def rate_limited(error):
        if app.config.get("DEBUG"):
            raise error
        return (
            render_template("error.html", code=429, message="Too Many Requests"),
            429,
        )

    @app.errorhandler(500)
    def internal_error(error):
        if app.config.get("DEBUG"):
            raise error
        return (
            render_template("error.html", code=500, message="Internal Server Error"),
            500,
        )
