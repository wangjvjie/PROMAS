"""
Centralized configuration loader for the log viewer application.

Parses environment variables from .env and defines typed configuration
classes for secure session handling, rate limiting, and log directory access.
"""

import os
from datetime import timedelta
from pathlib import Path

from dotenv import load_dotenv as _load_dotenv


def load_dotenv() -> bool:
    """Load environment variables from the .env file into os.environ.

    Returns:
        True if the .env file was found and loaded, False otherwise.
    """
    env_path = Path(__file__).resolve().parent.parent / ".env"
    return _load_dotenv(dotenv_path=env_path, override=False)


class Config:
    """Application configuration loaded from environment variables.

    All attributes are typed and validated at construction time.
    """

    SECRET_KEY: str
    ADMIN_USERNAME: str
    ADMIN_PASSWORD_HASH: str
    LOG_DIR: str
    FLASK_ENV: str
    RATELIMIT_DEFAULT: str
    SESSION_COOKIE_HTTPONLY: bool
    SESSION_COOKIE_SECURE: bool
    SESSION_COOKIE_SAMESITE: str
    PERMANENT_SESSION_LIFETIME: timedelta

    def __init__(self) -> None:
        # Ensure .env is loaded before reading values
        load_dotenv()

        self.SECRET_KEY = self._require_env("SECRET_KEY")
        self.ADMIN_USERNAME = self._require_env("ADMIN_USERNAME")
        self.ADMIN_PASSWORD_HASH = self._require_env("ADMIN_PASSWORD_HASH")
        self.LOG_DIR = os.environ.get("LOG_DIR", "/var/log")
        self.FLASK_ENV = os.environ.get("FLASK_ENV", "production")
        self.RATELIMIT_DEFAULT = os.environ.get("RATELIMIT_DEFAULT", "30 per minute")

        # Session cookie security flags
        self.SESSION_COOKIE_HTTPONLY = self._parse_bool(
            os.environ.get("SESSION_COOKIE_HTTPONLY", "True")
        )
        self.SESSION_COOKIE_SECURE = self._parse_bool(
            os.environ.get("SESSION_COOKIE_SECURE", "True")
        )
        self.SESSION_COOKIE_SAMESITE = os.environ.get(
            "SESSION_COOKIE_SAMESITE", "Lax"
        )

        # Session lifetime in seconds (default: 1 hour)
        lifetime_seconds = int(
            os.environ.get("PERMANENT_SESSION_LIFETIME", "3600")
        )
        self.PERMANENT_SESSION_LIFETIME = timedelta(seconds=lifetime_seconds)

        # Validate critical paths
        if not Path(self.LOG_DIR).is_dir():
            raise ValueError(
                f"LOG_DIR '{self.LOG_DIR}' does not exist or is not a directory"
            )

    @staticmethod
    def _require_env(key: str) -> str:
        """Retrieve a required environment variable or raise."""
        value = os.environ.get(key)
        if not value:
            raise ValueError(f"Required environment variable '{key}' is not set")
        return value

    @staticmethod
    def _parse_bool(value: str) -> bool:
        """Parse a boolean string (case-insensitive)."""
        return value.strip().lower() in ("true", "1", "yes", "on")
