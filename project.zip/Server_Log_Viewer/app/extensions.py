"""Extension registry to prevent circular imports.

Instantiates Flask-Login and Flask-Limiter, and provides initialization
routines bound to the application context.
"""

from flask import Flask
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_login import LoginManager

# Module-level extension instances to allow direct import by blueprints
# without circular dependencies.
login_manager = LoginManager()
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=[],
    storage_uri="memory://",
)


class ExtensionRegistry:
    """Central registry for Flask extensions to avoid circular imports."""

    def __init__(self) -> None:
        self.login_manager = login_manager
        self.limiter = limiter

    def init_app(self, app: Flask) -> None:
        """Initialize all extensions with the Flask application.

        Args:
            app: The Flask application instance.
        """
        self.login_manager.init_app(app)
        self.limiter.init_app(app)
