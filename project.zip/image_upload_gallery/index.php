<?php
session_start();
require_once __DIR__ . '/lib/security.php';

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'self'; img-src 'self'");

// Page router — allowlist only, never concatenate $_GET directly
$pages = [
    'upload'  => __DIR__ . '/pages/upload.php',
    'gallery' => __DIR__ . '/pages/gallery.php',
    'about'   => __DIR__ . '/pages/about.php',
];

$page = $_GET['page'] ?? 'gallery';

if (!array_key_exists($page, $pages)) {
    $page = '404';
    $includePath = null;
} else {
    $includePath = $pages[$page];
}

include __DIR__ . '/templates/header.php';

if ($includePath && file_exists($includePath)) {
    include $includePath;
} else {
    echo '<div class="container"><h2>404 — Page not found</h2></div>';
}

include __DIR__ . '/templates/footer.php';
