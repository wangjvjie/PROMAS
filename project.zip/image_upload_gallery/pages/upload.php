<?php
// pages/upload.php

$uploadsDir = __DIR__ . '/../uploads/';
$message    = null;
$success    = false;

/**
 * Full upload pipeline: CSRF → size → MIME → rename → move.
 */
function handleUpload(array $file, string $uploadsDir): array {
    // 1. CSRF
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        return ['ok' => false, 'message' => 'Invalid or expired CSRF token.'];
    }

    // 2. PHP upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'message' => 'Upload error code: ' . $file['error']];
    }

    // 3. File size
    if ($file['size'] > MAX_FILE_SIZE) {
        return ['ok' => false, 'message' => 'File exceeds the 5 MB limit.'];
    }

    // 4. MIME type (server-side, not browser-supplied)
    $ext = validateMime($file['tmp_name']);
    if ($ext === false) {
        return ['ok' => false, 'message' => 'Unsupported file type. Only JPEG, PNG, GIF, and WebP are allowed.'];
    }

    // 5. Safe filename — original name is discarded
    $safeName = sanitiseFilename($file['name'], $ext);
    $dest     = $uploadsDir . $safeName;

    // 6. Move
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return ['ok' => false, 'message' => 'Failed to save the file. Check directory permissions.'];
    }

    return ['ok' => true, 'message' => 'Photo uploaded successfully.'];
}

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_FILES['photo'])) {
        $message = 'No file received.';
    } else {
        $result  = handleUpload($_FILES['photo'], $uploadsDir);
        $success = $result['ok'];
        $message = $result['message'];
    }
}

$token = generateCsrfToken();
?>

<div class="container">
    <h2>Upload a Photo</h2>

    <?php if ($message): ?>
        <div class="alert <?= $success ? 'alert-success' : 'alert-error' ?>">
            <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="upload-form">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
        <div class="form-group">
            <label for="photo">Choose an image (JPEG, PNG, GIF, WebP — max 5 MB):</label>
            <input type="file" name="photo" id="photo" accept="image/jpeg,image/png,image/gif,image/webp">
        </div>
        <button type="submit" class="btn">Upload</button>
    </form>
</div>
