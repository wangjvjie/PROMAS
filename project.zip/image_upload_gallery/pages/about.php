<?php
// pages/about.php
?>
<div class="container">
    <h2>About</h2>
    <p>This is a simple personal photo gallery. You can upload JPEG, PNG, GIF, or WebP images and browse them in the gallery.</p>
    <p>Built with plain PHP — no frameworks, no databases, no external dependencies.</p>
</div>
