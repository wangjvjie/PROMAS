<?php
// pages/gallery.php

/**
 * Returns sorted array of relative paths to images in uploads/.
 */
function listImages(string $uploadsDir): array {
    $patterns = ['*.jpg', '*.png', '*.gif', '*.webp'];
    $files    = [];
    foreach ($patterns as $pattern) {
        $found = glob($uploadsDir . $pattern);
        if ($found) {
            $files = array_merge($files, $found);
        }
    }
    sort($files);
    return $files;
}

$uploadsDir = __DIR__ . '/../uploads/';
$images     = listImages($uploadsDir);
?>

<div class="container">
    <h2>Gallery</h2>

    <?php if (empty($images)): ?>
        <p class="empty-msg">No photos yet. <a href="?page=upload">Upload one!</a></p>
    <?php else: ?>
        <div class="gallery-grid">
            <?php foreach ($images as $imgPath):
                // Use only basename — never expose server paths
                $basename = basename($imgPath);
                $safeUrl  = 'uploads/' . htmlspecialchars($basename, ENT_QUOTES, 'UTF-8');
                $safeAlt  = htmlspecialchars($basename, ENT_QUOTES, 'UTF-8');
            ?>
                <div class="gallery-item">
                    <img src="<?= $safeUrl ?>" alt="<?= $safeAlt ?>" loading="lazy">
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
