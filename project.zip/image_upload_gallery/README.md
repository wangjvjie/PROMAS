# Image Upload Gallery

A minimal PHP photo gallery — upload images and browse them in a grid.

## Requirements
- PHP 8.0 or newer with `fileinfo` extension enabled
- Apache with `mod_rewrite` and `mod_headers` enabled  
  (or any server that serves `index.php` as the entry point)

## Quick Start

```bash
git clone <repo>
cd image_upload_gallery
chmod 755 uploads/
php -S localhost:8080
```

Then open http://localhost:8080

> **Note:** The built-in PHP dev server does not process `.htaccess`.  
> For production, use Apache or Nginx with the appropriate rewrite rules.

## File Structure

```
image_upload_gallery/
├── index.php              Entry point and page router
├── .htaccess              Security headers + rewrite rules
├── prd.md                 Product requirements
├── architecture.json      Full architecture design
├── threat_model.md        Threat model (CWE-434, CWE-22)
├── lib/
│   └── security.php       CSRF, MIME validation, filename sanitiser
├── pages/
│   ├── upload.php         Upload form + handler
│   ├── gallery.php        Image grid
│   └── about.php          Static about page
├── templates/
│   ├── header.php         HTML head + nav
│   └── footer.php         Closing tags
└── uploads/
    └── .htaccess          Blocks PHP execution in uploads/
```

## Required php.ini Settings

```ini
allow_url_include = Off
allow_url_fopen   = Off        ; recommended
upload_max_filesize = 5M
post_max_size = 6M
```

## Security Notes

| Control | Implementation |
|---|---|
| File type validation | `finfo_file()` on server tmp file — never `$_FILES['type']` |
| Filename safety | SHA-256 hash rename — original name discarded |
| Path traversal prevention | Page router uses allowlist, never concatenates `$_GET` |
| PHP webshell prevention | `uploads/.htaccess` disables PHP engine in that directory |
| CSRF protection | Synchronizer token with `hash_equals()` constant-time check |
| XSS prevention | `htmlspecialchars()` on all output; strict CSP header |
