<?php
// lib/security.php — CSRF helpers, MIME validator, filename sanitiser

const ALLOWED_MIME = [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/gif'  => 'gif',
    'image/webp' => 'webp',
];

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

/**
 * Generate and store a CSRF token in the session.
 */
function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validate the submitted token using constant-time comparison.
 * Regenerates on success.
 */
function verifyCsrfToken(string $submitted): bool {
    $stored = $_SESSION['csrf_token'] ?? '';
    if (!hash_equals($stored, $submitted)) {
        return false;
    }
    // Regenerate after use
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return true;
}

/**
 * Validate MIME type via finfo (never trust $_FILES['type']).
 * Returns the safe extension on success, false on failure.
 *
 * @param string $tmpPath
 * @return string|false
 */
function validateMime(string $tmpPath) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $tmpPath);
    finfo_close($finfo);

    // Explicitly block SVG — it can carry JavaScript
    if ($mime === 'image/svg+xml') {
        return false;
    }

    return ALLOWED_MIME[$mime] ?? false;
}

/**
 * Generate a safe, hash-based filename. Ignores original name entirely.
 */
function sanitiseFilename(string $originalName, string $extension): string {
    $hash = hash('sha256', $originalName . microtime(true) . random_bytes(8));
    return $hash . '.' . $extension;
}

/**
 * Assert that critical server configuration is acceptable.
 * Emits a warning in the page if something is misconfigured.
 */
function checkServerConfig(): array {
    $warnings = [];
    if (ini_get('allow_url_include')) {
        $warnings[] = 'allow_url_include is On — disable it in php.ini';
    }
    $uploadsHtaccess = __DIR__ . '/../uploads/.htaccess';
    if (!file_exists($uploadsHtaccess)) {
        $warnings[] = 'uploads/.htaccess is missing — PHP files in uploads/ may be executable';
    }
    return $warnings;
}
