<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo Gallery</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <a href="?page=gallery" class="brand">📷 Gallery</a>
    <a href="?page=gallery">Gallery</a>
    <a href="?page=upload">Upload</a>
    <a href="?page=about">About</a>
</nav>
