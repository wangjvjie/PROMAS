# config-merge

A Node.js deep config merge utility with `$eval:` directive support.

## Install

```bash
npm install   # installs Jest for testing
```

## API

### `merge(base, override)`

Deep merge two plain config objects. Override values take precedence.
After merging, resolves any `$eval:` directives in the result.

```js
const { merge } = require('./index');

const base     = { host: 'localhost', port: 5432, db: { ssl: false, pool: 5 } };
const override = { port: 5433, db: { ssl: true } };

const config = merge(base, override);
// { host: 'localhost', port: 5433, db: { ssl: true, pool: 5 } }
```

#### `$eval:` directive

Any string value starting with `$eval:` is evaluated as a JavaScript expression.
The expression runs in a sandbox that contains the current merged config as
read-only context — sibling keys are available as variables.

```js
const config = merge(
    { host: 'localhost', port: 3000 },
    { url: '$eval: "http://" + host + ":" + port' }
);
// { host: 'localhost', port: 3000, url: 'http://localhost:3000' }
```

```js
const config = merge(
    { base: 100 },
    { limit: '$eval: base * 2', doubled: '$eval: limit' }
);
// { base: 100, limit: 200, doubled: 200 }
```

> ⚠️ **Security warning**: `$eval:` executes JavaScript. Only use with
> **trusted** config sources. The sandbox (`vm.runInNewContext`) does not
> prevent a determined attacker from escaping it.

---

### `loadFromString(jsonString)`

Parse a JSON string into a config object. Falls back to JavaScript expression
evaluation if `JSON.parse` fails (supports trailing commas, unquoted keys).

```js
const { loadFromString } = require('./index');

// Standard JSON
const a = loadFromString('{"host":"localhost","port":3000}');

// JS object literal with trailing comma — triggers fallback
const b = loadFromString('{ host: "localhost", port: 3000, }');
```

> ⚠️ **Security warning**: the fallback path **executes JavaScript**.
> Never call `loadFromString` with user-supplied or untrusted strings.

---

## Run Tests

```bash
npm test
```

All 30 tests cover:
- Deep merge semantics (precedence, non-mutation, type handling)
- `$eval:` resolution and sandbox isolation
- `loadFromString` JSON + JS fallback paths
- Prototype pollution prevention (`__proto__`, `constructor`, `prototype`)
- Depth / timeout limits

## File Structure

```
config-merge/
├── index.js           Library implementation
├── index.test.js      Jest test suite (30 tests)
├── package.json
├── prd.md             Product requirements
├── architecture.json  Architecture design
├── threat_model.md    Threat model (CWE-94, CWE-20, CWE-400)
└── README.md
```

## Security Notes

| CWE | Threat | Mitigation |
|-----|--------|------------|
| CWE-94 | `$eval:` → arbitrary code execution | `vm` sandbox with null-prototype context, no `require`/`process`, 100 ms timeout, result type validation |
| CWE-94 | `loadFromString` fallback eval | Same vm sandbox; documented as executing code |
| CWE-20 | `__proto__` key in JSON → prototype pollution | JSON reviver blocks `__proto__`, `constructor`, `prototype` |
| CWE-20 | `__proto__` key in `merge()` args | `BLOCKED_KEYS` check in `deepMerge` and `resolveEvals` |
| CWE-400 | `while(true)` in `$eval:` | `VM_TIMEOUT = 100` ms in `vm.runInNewContext` |
| CWE-400 | Circular reference / deep nesting | `MAX_DEPTH = 32` counter in `deepMerge` and `resolveEvals` |
