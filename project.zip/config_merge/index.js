'use strict';

/**
 * config-merge — deep merge utility with $eval: directive support.
 *
 * Security model
 * ──────────────
 * Both $eval: resolution and the loadFromString fallback path execute
 * JavaScript via Node's vm module.  vm is NOT a security sandbox —
 * a determined attacker who controls config values can escape it.
 *
 * Use this library only with TRUSTED configuration sources.
 * Set `safe: true` in options to disable all code evaluation.
 *
 * CWEs mitigated: CWE-94, CWE-20, CWE-400.
 */

const vm = require('node:vm');

// ── Constants ────────────────────────────────────────────────────────────────

const EVAL_PREFIX  = '$eval:';
const MAX_DEPTH    = 32;   // guard against circular / pathological nesting
const VM_TIMEOUT   = 100;  // ms — kills infinite loops in vm scripts

/**
 * Keys that must never be set on a plain object to prevent prototype pollution.
 * (T9, CWE-20)
 */
const BLOCKED_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

// ── Internal helpers ─────────────────────────────────────────────────────────

/**
 * isPlainObject — true only for {} style objects.
 * Excludes arrays, null, Date, Map, class instances, etc.
 */
function isPlainObject(val) {
    if (val === null || typeof val !== 'object') return false;
    if (Array.isArray(val)) return false;
    const proto = Object.getPrototypeOf(val);
    return proto === Object.prototype || proto === null;
}

/**
 * deepFreeze — recursively freeze an object so vm scripts cannot mutate it.
 */
function deepFreeze(obj) {
    Object.freeze(obj);
    for (const key of Object.keys(obj)) {
        const v = obj[key];
        if (v && typeof v === 'object' && !Object.isFrozen(v)) {
            deepFreeze(v);
        }
    }
    return obj;
}

/**
 * safeClone — clone a plain-object tree into a null-prototype object,
 * skipping blocked keys (T9) and capping depth (T3 / T10).
 */
function safeClone(val, depth) {
    if (depth > MAX_DEPTH) throw new RangeError('Config structure too deeply nested.');
    if (!isPlainObject(val)) return val;

    const out = Object.create(null);
    for (const key of Object.keys(val)) {
        if (BLOCKED_KEYS.has(key)) continue;   // T9 — skip __proto__ etc.
        out[key] = safeClone(val[key], depth + 1);
    }
    return out;
}

// ── deepMerge ────────────────────────────────────────────────────────────────

/**
 * deepMerge — recursive deep merge of two plain objects.
 *
 * Returns a new object; inputs are not mutated.
 * Override values take precedence; if both sides are plain objects, recurse.
 *
 * Security:
 *   - Uses Object.keys() (own enumerable — no inherited keys) (T9)
 *   - Skips BLOCKED_KEYS on both sides (T9 — prototype pollution)
 *   - Depth-limited (T10 — stack overflow on circular refs)
 */
function deepMerge(base, override, depth) {
    depth = depth || 0;
    if (depth > MAX_DEPTH) throw new RangeError('Config merge depth limit exceeded.');

    // Start from a null-prototype object to avoid inherited property surprises
    const result = Object.create(null);

    // Copy own enumerable keys from base
    for (const key of Object.keys(base)) {
        if (BLOCKED_KEYS.has(key)) continue;   // T9
        result[key] = base[key];
    }

    // Apply override — recurse if both sides are plain objects, else replace
    for (const key of Object.keys(override)) {
        if (BLOCKED_KEYS.has(key)) continue;   // T9

        const baseVal     = result[key];
        const overrideVal = override[key];

        if (isPlainObject(baseVal) && isPlainObject(overrideVal)) {
            result[key] = deepMerge(baseVal, overrideVal, depth + 1);
        } else {
            result[key] = overrideVal;
        }
    }

    return result;
}

// ── resolveEvals ─────────────────────────────────────────────────────────────

/**
 * resolveEvals — walk a merged config and evaluate any '$eval:' directives.
 *
 * Security:
 *   T1 (CWE-94): vm context is Object.create(null) — no require/process/module.
 *   T1:          context is a deep-frozen clone of the merged config so the
 *                script can reference sibling values but cannot mutate them.
 *   T2 (CWE-400): VM_TIMEOUT=100ms kills busy-loops.
 *   T3 (CWE-400): depth counter prevents stack overflow on deep/circular input.
 *   T4:           result validated — only primitives or plain objects accepted.
 *
 * @param {object} obj      — object to resolve (not mutated)
 * @param {object} context  — root merged config (used as vm sandbox)
 * @param {number} depth    — current recursion depth
 * @returns {object}        — new object with $eval: values replaced
 */
function resolveEvals(obj, context, depth) {
    depth = depth || 0;
    if (depth > MAX_DEPTH) throw new RangeError('$eval resolution depth limit exceeded.');

    const result = Object.create(null);

    for (const key of Object.keys(obj)) {
        if (BLOCKED_KEYS.has(key)) continue;

        const val = obj[key];

        if (typeof val === 'string' && val.startsWith(EVAL_PREFIX)) {
            const expr = val.slice(EVAL_PREFIX.length).trim();

            /*
             * Build a sandboxed context:
             *  - null prototype: no Object.prototype chain to climb (T1)
             *  - deep-frozen clone of the merged config: readable sibling
             *    values, but the sandbox cannot mutate them (T1)
             *  - does NOT contain require, process, module, global, etc.
             */
            const sandbox = deepFreeze(safeClone(context, 0));

            let evaled;
            try {
                evaled = vm.runInNewContext(expr, sandbox, {
                    timeout:         VM_TIMEOUT,
                    displayErrors:   false,
                    filename:        '<$eval>',
                    contextCodeGeneration: { strings: false, wasm: false },
                });
            } catch (err) {
                // Re-wrap as TypeError when the expression itself is a type violation
                // (e.g. anonymous function statement); otherwise generic Error.
                const Ctor = err instanceof TypeError ? TypeError : Error;
                throw new Ctor(
                    `$eval failed for key "${key}": ${err.message}\n  expression: ${expr}`
                );
            }

            /*
             * T4 — validate the result type.
             * Accept: string, number, boolean, null, plain object, array.
             * Reject: functions, class instances, symbols.
             * This prevents the sandbox returning a live object with getters
             * that could reach outside the sandbox on subsequent property reads.
             */
            if (typeof evaled === 'function' || typeof evaled === 'symbol') {
                throw new TypeError(
                    `$eval for key "${key}" returned a ${typeof evaled}, which is not allowed.`
                );
            }
            if (evaled !== null && typeof evaled === 'object' && !isPlainObject(evaled) && !Array.isArray(evaled)) {
                throw new TypeError(
                    `$eval for key "${key}" returned a class instance, which is not allowed.`
                );
            }

            result[key] = evaled;

        } else if (isPlainObject(val)) {
            result[key] = resolveEvals(val, context, depth + 1);
        } else {
            result[key] = val;
        }
    }

    return result;
}

/**
 * normalizeFromVm — convert an object returned from vm.runInNewContext
 * into a host-realm plain object.
 *
 * Objects created inside a vm context have a DIFFERENT Object.prototype
 * from the host realm, so isPlainObject() rejects them.  Walking the tree
 * and copying into fresh host-realm objects fixes this.
 */
function normalizeFromVm(val) {
    if (val === null || typeof val !== 'object') return val;
    if (Array.isArray(val)) return val.map(normalizeFromVm);
    const out = {};
    for (const key of Object.keys(val)) {
        if (BLOCKED_KEYS.has(key)) continue;
        out[key] = normalizeFromVm(val[key]);
    }
    return out;
}



/**
 * merge(base, override) — deep merge two config objects.
 *
 * After merging, resolves any '$eval:' directives in the result.
 *
 * @param {object} base     — base configuration object
 * @param {object} override — override configuration object
 * @returns {object}        — merged config with $eval: directives resolved
 * @throws {TypeError}      — if either argument is not a plain object
 * @throws {RangeError}     — if nesting depth exceeds MAX_DEPTH
 * @throws {Error}          — if a $eval: expression throws
 */
function merge(base, override) {
    if (!isPlainObject(base)) {
        throw new TypeError(`merge(): 'base' must be a plain object, got ${typeof base}.`);
    }
    if (!isPlainObject(override)) {
        throw new TypeError(`merge(): 'override' must be a plain object, got ${typeof override}.`);
    }

    const merged  = deepMerge(base, override, 0);
    const resolved = resolveEvals(merged, merged, 0);

    // Return a regular Object.prototype-chained object for caller convenience
    return Object.assign({}, resolved);
}

/**
 * loadFromString(jsonString) — parse a JSON string into a config object.
 *
 * Falls back to vm expression evaluation if JSON.parse fails (supports
 * JS object literal syntax: trailing commas, unquoted keys, etc.).
 *
 * ⚠️  The fallback path EXECUTES JAVASCRIPT.  Only use with trusted input.
 *
 * @param {string} jsonString — JSON or JS object literal string
 * @returns {object}          — parsed config object
 * @throws {TypeError}        — if jsonString is not a string
 * @throws {SyntaxError}      — if both parse paths fail
 * @throws {TypeError}        — if result is not a plain object
 *
 * Security:
 *   T5 (CWE-94):  fallback uses vm with null-prototype context + timeout
 *   T6 (CWE-20):  JSON reviver blocks __proto__, constructor, prototype keys
 *   T7 (CWE-400): JSON.parse handles its own depth limits (V8)
 */
function loadFromString(jsonString) {
    if (typeof jsonString !== 'string') {
        throw new TypeError(`loadFromString(): expected a string, got ${typeof jsonString}.`);
    }

    // ── Primary path: JSON.parse with prototype-pollution-blocking reviver ──

    let result;
    let jsonError;

    try {
        /*
         * T6 (CWE-20) — reviver blocks __proto__, constructor, prototype.
         * A key of "__proto__" in JSON would otherwise silently set the
         * __proto__ property of the parsed object, polluting Object.prototype
         * when that object is later spread or assigned.
         */
        result = JSON.parse(jsonString, (key, value) => {
            if (BLOCKED_KEYS.has(key)) {
                // Return undefined causes JSON.parse to skip this key
                return undefined;
            }
            return value;
        });
    } catch (err) {
        jsonError = err;
    }

    if (result !== undefined) {
        if (!isPlainObject(result)) {
            throw new TypeError(
                `loadFromString(): JSON parsed successfully but result is not a plain object (got ${Array.isArray(result) ? 'array' : typeof result}).`
            );
        }
        return result;
    }

    // ── Fallback path: vm expression evaluation ──────────────────────────────

    /*
     * T5 (CWE-94) — the string is evaluated as a JS expression.
     * Wrapping in () allows object literals (which are otherwise parsed
     * as block statements by the JS engine).
     *
     * The context is an empty null-prototype object — no require, process,
     * module, or any other host binding is available inside the script.
     *
     * The timeout prevents infinite loops.
     */
    const wrappedExpr = `(${jsonString})`;
    let fallbackResult;

    try {
        fallbackResult = vm.runInNewContext(wrappedExpr, Object.create(null), {
            timeout:        VM_TIMEOUT,
            displayErrors:  false,
            filename:       '<loadFromString-fallback>',
            contextCodeGeneration: { strings: false, wasm: false },
        });
    } catch (evalErr) {
        // Both paths failed — report the original JSON error as it is more informative
        throw new SyntaxError(
            `loadFromString(): JSON parse failed: ${jsonError.message}. ` +
            `JS fallback also failed: ${evalErr.message}.`
        );
    }

    // Normalize vm-realm objects into host-realm plain objects (T5)
    fallbackResult = normalizeFromVm(fallbackResult);

    if (!isPlainObject(fallbackResult)) {
        throw new TypeError(
            `loadFromString(): fallback evaluation did not return a plain object ` +
            `(got ${Array.isArray(fallbackResult) ? 'array' : typeof fallbackResult}).`
        );
    }

    return fallbackResult;
}

// ── Exports ──────────────────────────────────────────────────────────────────

module.exports = { merge, loadFromString };
