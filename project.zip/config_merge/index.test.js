'use strict';

const { merge, loadFromString } = require('./index');

// ── merge() ──────────────────────────────────────────────────────────────────

describe('merge()', () => {

    test('override values take precedence over base', () => {
        const result = merge({ a: 1, b: 2 }, { b: 99, c: 3 });
        expect(result).toMatchObject({ a: 1, b: 99, c: 3 });
    });

    test('deep merges nested plain objects', () => {
        const base     = { db: { host: 'localhost', port: 5432, opts: { ssl: false } } };
        const override = { db: { port: 5433, opts: { ssl: true } } };
        expect(merge(base, override)).toMatchObject({
            db: { host: 'localhost', port: 5433, opts: { ssl: true } }
        });
    });

    test('non-object override replaces, not merges', () => {
        // array replaces object
        expect(merge({ a: { x: 1 } }, { a: [1, 2, 3] })).toMatchObject({ a: [1, 2, 3] });
    });

    test('does not mutate base or override', () => {
        const base     = { a: 1 };
        const override = { a: 2 };
        merge(base, override);
        expect(base.a).toBe(1);
        expect(override.a).toBe(2);
    });

    test('throws TypeError if base is not a plain object', () => {
        expect(() => merge([1, 2], {})).toThrow(TypeError);
        expect(() => merge(null, {})).toThrow(TypeError);
        expect(() => merge('string', {})).toThrow(TypeError);
    });

    test('throws TypeError if override is not a plain object', () => {
        expect(() => merge({}, 42)).toThrow(TypeError);
    });

    // ── Prototype pollution guards (T9 — CWE-20) ─────────────────────────

    test('does not pollute Object.prototype via __proto__ key in override', () => {
        const malicious = JSON.parse('{"__proto__":{"polluted":true}}');
        merge({}, malicious);
        expect(({}).polluted).toBeUndefined();
    });

    test('does not pollute via constructor key', () => {
        const before = Object.prototype.toString;
        merge({}, { constructor: { prototype: { toString: 'hacked' } } });
        expect(Object.prototype.toString).toBe(before);
    });

    // ── $eval: directive ──────────────────────────────────────────────────

    test('$eval: resolves arithmetic expression', () => {
        const result = merge(
            { limit: 10 },
            { doubled: '$eval: limit * 2' }
        );
        expect(result.doubled).toBe(20);
    });

    test('$eval: can reference sibling keys in merged config', () => {
        const result = merge(
            { host: 'localhost', port: 3000 },
            { url: '$eval: "http://" + host + ":" + port' }
        );
        expect(result.url).toBe('http://localhost:3000');
    });

    test('$eval: resolves nested directives', () => {
        const result = merge(
            { base: 5 },
            { nested: { computed: '$eval: base + 1' } }
        );
        expect(result.nested.computed).toBe(6);
    });

    test('$eval: throws on invalid expression', () => {
        expect(() => merge({}, { x: '$eval: !!@#invalid syntax' })).toThrow(Error);
    });

    test('$eval: throws on infinite loop (timeout)', () => {
        expect(() => merge({}, { x: '$eval: while(true){}' })).toThrow();
    });

    test('$eval: throws when expression returns a function (T4)', () => {
        // Arrow function is a valid expression that returns a function value
        expect(() => merge({}, { x: '$eval: () => 1' })).toThrow(TypeError);
    });

    test('$eval: sandbox has no access to require', () => {
        expect(() =>
            merge({}, { x: "$eval: require('fs').readFileSync('/etc/passwd','utf8')" })
        ).toThrow(); // require is not defined in sandbox
    });

    test('$eval: sandbox has no access to process', () => {
        expect(() =>
            merge({}, { x: '$eval: process.env.SECRET' })
        ).toThrow(); // process is not defined in sandbox
    });

    // ── Depth limit ───────────────────────────────────────────────────────

    test('throws RangeError on excessively deep config', () => {
        let deep = { value: 1 };
        for (let i = 0; i < 40; i++) deep = { nested: deep };
        expect(() => merge({}, deep)).toThrow(RangeError);
    });

});

// ── loadFromString() ─────────────────────────────────────────────────────────

describe('loadFromString()', () => {

    test('parses valid JSON', () => {
        const result = loadFromString('{"host":"localhost","port":3000}');
        expect(result).toMatchObject({ host: 'localhost', port: 3000 });
    });

    test('parses JS object literal via fallback (trailing comma)', () => {
        const result = loadFromString('{ host: "localhost", port: 3000, }');
        expect(result).toMatchObject({ host: 'localhost', port: 3000 });
    });

    test('parses JS object literal with unquoted keys via fallback', () => {
        const result = loadFromString('{ debug: true, retries: 3 }');
        expect(result).toMatchObject({ debug: true, retries: 3 });
    });

    test('throws TypeError for non-string input', () => {
        expect(() => loadFromString(42)).toThrow(TypeError);
        expect(() => loadFromString(null)).toThrow(TypeError);
    });

    test('throws SyntaxError for completely invalid input', () => {
        expect(() => loadFromString('not valid at all !!!')).toThrow(SyntaxError);
    });

    test('throws TypeError when JSON is an array, not object', () => {
        expect(() => loadFromString('[1,2,3]')).toThrow(TypeError);
    });

    test('throws TypeError when fallback result is not a plain object', () => {
        expect(() => loadFromString('"just a string"')).toThrow(TypeError);
    });

    // ── Prototype pollution guard in JSON path (T6 — CWE-20) ─────────────

    test('JSON reviver strips __proto__ key to prevent prototype pollution', () => {
        const before = ({}).polluted;
        loadFromString('{"__proto__":{"polluted":"yes"},"safe":1}');
        expect(({}).polluted).toBe(before);
    });

    test('JSON reviver strips constructor key (own property blocked, inherited unavoidable)', () => {
        const result = loadFromString('{"constructor":{"name":"hacked"},"a":1}');
        // The reviver drops the own "constructor" key; Object.prototype.constructor
        // is still inherited — that is expected and harmless (it is not a pollution).
        expect(Object.prototype.hasOwnProperty.call(result, 'constructor')).toBe(false);
        expect(result.a).toBe(1);
    });

    // ── Sandbox isolation in fallback path (T5 — CWE-94) ─────────────────

    test('fallback sandbox has no require', () => {
        // This is not valid JSON but is valid JS — hits the fallback
        expect(() =>
            loadFromString("{ x: require('os').hostname() }")
        ).toThrow(); // require not defined in sandbox
    });

    test('fallback sandbox has no process', () => {
        expect(() =>
            loadFromString('{ x: process.env.PATH }')
        ).toThrow();
    });

    test('fallback timeout kills infinite loop', () => {
        expect(() =>
            loadFromString('(function(){ while(true){} return {}; })()')
        ).toThrow();
    });

});
